<?php

// db connection

$servername="localhost";
$username="root";
$password="";
$dbname="PRECARE";

// create connecction

$conn=new mysqli($servername,$username,$password,$dbname);

// checing connection

if($conn->connect_error){
    die("connection failed");
}



?>