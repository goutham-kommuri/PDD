<?php
// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Define the base URL for images
$baseUrl = 'http://10.0.2.2/vivek/';

include "config.php";

// Get the username from the query parameters
$fetchUsername = isset($_GET['username']) ? $_GET['username'] : '';

// SQL query to fetch details for the specific username
$sql = "SELECT `image`, `username`, `gender`, `phoneNumber`, `email`, `password` FROM `bmi` WHERE `username` = '" . $conn->real_escape_string($fetchUsername) . "'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $rows = array();
  while ($row = $result->fetch_assoc()) {
    // Append the base URL to the image field to form the full URL
    $row['image'] = $baseUrl . $row['image'];
    $rows[] = $row;
  }
  
  // Return data as JSON
  header('Content-Type: application/json');
  echo json_encode($rows);
} else {
  echo json_encode(array('message' => 'No records found for username: ' . $fetchUsername));
}

$conn->close();
?>
