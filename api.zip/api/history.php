<?php
// Include database connection
include('db.php');  

// Set header for JSON response
header('Content-Type: application/json');

// Function to insert data into the history table
function InsertHistory($conn, $patient_name, $gender, $age, $weight, $height, $bmi, $lbm) {
    $stmt = $conn->prepare("INSERT INTO history (patient_name, gender, age, weight, height, bmi, lbm) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssidddd", $patient_name, $gender, $age, $weight, $height, $bmi, $lbm);

    if ($stmt->execute()) {
        $stmt->close();
        return [
            'status' => true,
            'message' => 'Record added successfully!'
        ];
    } else {
        $stmt->close();
        return [
            'status' => false,
            'message' => 'Error: ' . $conn->error
        ];
    }
}

// Read raw JSON input
$input = file_get_contents("php://input");
$data = json_decode($input, true);

// Debugging: Log received JSON data
error_log(json_encode($data));

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($data['patient_name'], $data['gender'], $data['age'], $data['weight'], $data['height'])) {
        // Assign values
        $patient_name = $data['patient_name'];
        $gender = $data['gender'];
        $age = (int)$data['age'];
        $weight = (float)$data['weight'];
        $height = (float)$data['height'];

        // Calculate BMI
        $height_m = $height / 100;
        $bmi = $weight / ($height_m * $height_m);

        // Calculate LBM
        $lbm = ($gender == "Male") ? (0.407 * $weight + 0.267 * $height - 19.2) 
                                   : (0.252 * $weight + 0.473 * $height - 48.3);

        // Insert into database
        $response = InsertHistory($conn, $patient_name, $gender, $age, $weight, $height, $bmi, $lbm);
        echo json_encode($response);
    } else {
        echo json_encode([
            'status' => false,
            'message' => 'Required fields are missing.',
            'received' => $data
        ]);
    }
} else {
    echo json_encode([
        'status' => false,
        'message' => 'Invalid request method. Use POST.'
    ]);
}

// Close connection
$conn->close();
?>
