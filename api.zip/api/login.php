<?php
// CORS headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

include "config.php";

// Get the posted data
$data = json_decode(file_get_contents("php://input"));

// Prepare and bind statement
$stmt = $conn->prepare("SELECT * FROM bmi WHERE username = ? AND password = ?");
$stmt->bind_param("ss", $data->username, $data->password);

// Execute the statement
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Check if there is a row with matching username and password
if ($result->num_rows > 0) {
    echo json_encode(["status" => "success", "message" => "Login successful"]);
} else {
    echo json_encode(["status" => "failure", "message" => "Invalid username or password"]);
}

// Close the connection
$stmt->close();
$conn->close();
?>
