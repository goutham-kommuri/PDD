<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

include "config.php";

$target_dir = "image/";
$image_path = "";

if (isset($_FILES['image'])) {
    $target_file = $target_dir . basename($_FILES['image']['name']);
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        $image_path = $target_file;
    } else {
        echo "Error: Could not upload the image.";
        exit;
    }
}

$username = $_POST['username'];
$gender = $_POST['gender'];
$phoneNumber = $_POST['phoneNumber'];
$email = $_POST['email'];
$password = $_POST['password'];

$checkQuery = "SELECT * FROM bmi WHERE username = ?";
$checkStmt = $conn->prepare($checkQuery);
$checkStmt->bind_param("s", $username);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    echo "Error: The username already exists.";
} else {
    $stmt = $conn->prepare("INSERT INTO bmi (username, gender, phoneNumber, email, password, image) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $username, $gender, $phoneNumber, $email, $password, $image_path);

    if ($stmt->execute()) {
        echo "New record created successfully.";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$checkStmt->close();
$conn->close();
?>
