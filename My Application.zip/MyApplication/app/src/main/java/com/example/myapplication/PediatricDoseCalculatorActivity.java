package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class PediatricDoseCalculatorActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pediatric_dose_calculator);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // Set click listeners for category buttons
        findViewById(R.id.btnAntibioticDrugs).setOnClickListener(v -> openCategory(Antibiotic.class));
        findViewById(R.id.btnAntipyreticAnalgesic).setOnClickListener(v -> openCategory(DrugListActivity.class, "Antipyretic And Analgesic Drugs"));
        findViewById(R.id.btnAntihistamineCorticosteroids).setOnClickListener(v -> openCategory(antihistamine.class));
        findViewById(R.id.btnGITDrugs).setOnClickListener(v -> openCategory(GIT.class));
        findViewById(R.id.btnRespiratoryTractDrugs).setOnClickListener(v -> openCategory(respiratory.class));
        findViewById(R.id.btnEquationsResources).setOnClickListener(v -> openCategory(DrugListActivity.class, "Equations And Resources"));
    }

    private void openCategory(Class<?> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
    }

    private void openCategory(Class<?> activityClass, String categoryName) {
        Intent intent = new Intent(this, activityClass);
        intent.putExtra("CATEGORY_NAME", categoryName);
        startActivity(intent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish(); // Close activity when back button is clicked
        return true;
    }
}
