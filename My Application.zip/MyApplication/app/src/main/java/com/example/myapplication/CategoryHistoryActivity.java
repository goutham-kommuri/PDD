package com.example.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CategoryHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CategoryAdapter adapter;
    private List<Category> categories = new ArrayList<>();
    private Map<String, DatabaseReference> databaseReferences = new HashMap<>();
    private ImageButton btnBack, clearHistoryButton;
    private TextView tvEmptyState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_history);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        initializeViews();
        setupButtons();
        initializeDatabaseReferences();
        loadAllCategories();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewCategories);
        btnBack = findViewById(R.id.btnBack); // Matches XML id
        clearHistoryButton = findViewById(R.id.clearHistoryButton); // Matches XML id
        tvEmptyState = findViewById(R.id.tvEmptyState);

        // Debug logging
        Log.d("ViewInit", "btnBack: " + (btnBack != null));
        Log.d("ViewInit", "clearHistoryButton: " + (clearHistoryButton != null));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CategoryAdapter(categories);
        recyclerView.setAdapter(adapter);
    }

    private void setupButtons() {
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> finish());
        } else {
            Log.e("CategoryHistory", "Back button is null");
        }

        if (clearHistoryButton != null) {
            clearHistoryButton.setOnClickListener(v -> showClearHistoryDialog());
        } else {
            Log.e("CategoryHistory", "Clear history button is null");
        }
    }

    private void showClearHistoryDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Clear History")
                .setMessage("Are you sure you want to delete all calculation history? This cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> clearAllHistory())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void clearAllHistory() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show();
            return;
        }

        String uid = user.getUid();
        DatabaseReference calculationsRef = FirebaseDatabase.getInstance().getReference()
                .child("calculations").child(uid);

        calculationsRef.removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(this, "History cleared successfully", Toast.LENGTH_SHORT).show();
                categories.clear();
                adapter.notifyDataSetChanged();
                checkEmptyState();
                loadAdditionalCategories();
            } else {
                Toast.makeText(this, "Failed to clear history", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void checkEmptyState() {
        if (categories.isEmpty()) {
            tvEmptyState.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvEmptyState.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void initializeDatabaseReferences() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String uid = user.getUid();
        databaseReferences.put("medications", FirebaseDatabase.getInstance().getReference()
                .child("calculations").child(uid));

        databaseReferences.put("bmi", FirebaseDatabase.getInstance().getReference()
                .child("bmi_records").child(uid));

        databaseReferences.put("crcl", FirebaseDatabase.getInstance().getReference()
                .child("records").child(uid));

        databaseReferences.put("dosage", FirebaseDatabase.getInstance().getReference()
                .child("drugdosage").child(uid));
    }
    private void loadAllCategories() {
        databaseReferences.get("medications").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                categories.clear();

                for (DataSnapshot categorySnapshot : snapshot.getChildren()) {
                    String categoryName = categorySnapshot.getKey();
                    int itemCount = (int) categorySnapshot.getChildrenCount();
                    categories.add(new Category(
                            categoryName,
                            itemCount,
                            "medication",
                            getMedicationType(categoryName)
                    ));
                }

                loadAdditionalCategories();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CategoryHistoryActivity.this,
                        "Error loading medications: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                loadAdditionalCategories();
            }
        });
    }

    private String getMedicationType(String categoryName) {
        switch (categoryName.toLowerCase()) {
            case "antibiotic": return "antibiotic";
            case "antipyretic": return "antipyretic";
            case "antihistamine": return "antihistamine";
            case "respiratory": return "respiratory";
            case "git": return "git";
            default: return "medication";
        }
    }

    private void loadAdditionalCategories() {
        databaseReferences.get("bmi").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int count = (int) snapshot.getChildrenCount();
                if (count > 0) {
                    categories.add(new Category("BMI Records", count, "bmi", "bmi"));
                }
                loadCrClRecords();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CategoryHistoryActivity.this,
                        "Error loading BMI: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                loadCrClRecords();
            }
        });
    }

    private void loadCrClRecords() {
        databaseReferences.get("crcl").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int count = (int) snapshot.getChildrenCount();
                if (count > 0) {
                    categories.add(new Category("CrCl Records", count, "crcl", "crcl"));
                }
                loadDrugDosage();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CategoryHistoryActivity.this,
                        "Error loading CrCl: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                loadDrugDosage();
            }
        });
    }

    private void loadDrugDosage() {
        databaseReferences.get("dosage").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int count = (int) snapshot.getChildrenCount();
                if (count > 0) {
                    categories.add(new Category("Drug Dosage", count, "dosage", "dosage"));
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CategoryHistoryActivity.this,
                        "Error loading drug dosage: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                adapter.notifyDataSetChanged();
            }
        });
    }

    private class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.ViewHolder> {

        private List<Category> categories;

        public CategoryAdapter(List<Category> categories) {
            this.categories = categories;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_category, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Category category = categories.get(position);

            holder.categoryName.setText(category.name);
            holder.itemCount.setText(String.valueOf(category.count));

            int iconRes = getCategoryIcon(category);
            int colorRes = getCategoryColor(category);
            holder.categoryIcon.setImageResource(iconRes);
            holder.categoryIcon.setColorFilter(ContextCompat.getColor(
                    CategoryHistoryActivity.this, colorRes));

            holder.itemView.setOnClickListener(v -> {
                Intent intent = new Intent(CategoryHistoryActivity.this,
                        UniversalHistoryActivity.class);
                intent.putExtra("CATEGORY_NAME", category.name);
                intent.putExtra("CATEGORY_TYPE", category.type);
                startActivity(intent);
            });
        }

        @Override
        public int getItemCount() {
            return categories.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            ImageView categoryIcon;
            TextView categoryName, itemCount;

            ViewHolder(View itemView) {
                super(itemView);
                categoryIcon = itemView.findViewById(R.id.ivCategoryIcon);
                categoryName = itemView.findViewById(R.id.tvCategoryName);
                itemCount = itemView.findViewById(R.id.tvItemCount);
            }
        }
    }

    private int getCategoryIcon(Category category) {
        switch (category.subType != null ? category.subType : category.type) {
            case "antibiotic": return R.drawable.antibiotic;
            case "antipyretic": return R.drawable.anticryctic;
            case "antihistamine": return R.drawable.allergy;
            case "respiratory": return R.drawable.res;
            case "git": return R.drawable.git;
            case "bmi": return R.drawable.bmi;
            case "crcl": return R.drawable.ic_kidney;
            case "dosage": return R.drawable.ic_antibiotics;
            default: return R.drawable.ic_medication;
        }
    }

    private int getCategoryColor(Category category) {
        switch (category.subType != null ? category.subType : category.type) {
            case "antibiotic": return R.color.antibiotic_color;
            case "antipyretic": return R.color.antipyretic_color;
            case "antihistamine": return R.color.antihistamine_color;
            case "respiratory": return R.color.respiratory_color;
            case "git": return R.color.git_color;
            case "bmi": return R.color.bmi_color;
            case "crcl": return R.color.crcl_color;
            case "dosage": return R.color.dosage_color;
            default: return R.color.primary;
        }
    }

    static class Category {
        String name;
        int count;
        String type;
        String subType;

        Category(String name, int count, String type, String subType) {
            this.name = name;
            this.count = count;
            this.type = type;
            this.subType = subType;
        }
    }
}