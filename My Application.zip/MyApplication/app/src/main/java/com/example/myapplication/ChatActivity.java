package com.example.myapplication;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ChatActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ChatAdapter chatAdapter;
    private List<Message> messageList;
    private EditText editTextMessage;
    private ImageButton sendButton;
    private ProgressBar progressBar;

    // ✅ Use ONLY the actual API key
    private static final String API_KEY = "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";
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        recyclerView = findViewById(R.id.recyclerView);
        editTextMessage = findViewById(R.id.editTextMessage);
        sendButton = findViewById(R.id.sendButton);
        progressBar = findViewById(R.id.progressBar);

        messageList = new ArrayList<>();
        chatAdapter = new ChatAdapter(messageList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(chatAdapter);

        // UI Customization
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        getWindow().setStatusBarColor(getResources().getColor(android.R.color.black));
        getWindow().setNavigationBarColor(getResources().getColor(android.R.color.black));

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        sendButton.setOnClickListener(v -> sendMessage());
    }

    private void sendMessage() {
        String message = editTextMessage.getText().toString().trim();
        if (TextUtils.isEmpty(message)) return;

        messageList.add(new Message(message, true)); // User message
        chatAdapter.notifyItemInserted(messageList.size() - 1);
        recyclerView.smoothScrollToPosition(messageList.size() - 1);

        editTextMessage.setText("");
        progressBar.setVisibility(View.VISIBLE);

        fetchResponseFromChatGPT(message);
    }

    private void fetchResponseFromChatGPT(String userMessage) {
        OkHttpClient client = new OkHttpClient();

        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("model", "gpt-4"); // ✅ Use "gpt-4" or "gpt-3.5-turbo"
            JSONArray messages = new JSONArray();
            messages.put(new JSONObject().put("role", "system").put("content", "You are a medical AI assistant."));
            messages.put(new JSONObject().put("role", "user").put("content", userMessage));
            jsonBody.put("messages", messages);
            jsonBody.put("max_tokens", 200);
            jsonBody.put("temperature", 0.7);
        } catch (Exception e) {
            e.printStackTrace();
        }

        RequestBody body = RequestBody.create(jsonBody.toString(), MediaType.get("application/json; charset=utf-8"));
        Request request = new Request.Builder()
                .url(API_URL)
                .header("Authorization", "Bearer " + API_KEY.trim()) // ✅ Use new OpenAI API key
                .header("Content-Type", "application/json")
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    messageList.add(new Message("❌ Network error. Please check your internet.", false));
                    chatAdapter.notifyItemInserted(messageList.size() - 1);
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    String responseBody = response.body().string();
                    JSONObject jsonResponse = new JSONObject(responseBody);

                    JSONArray choicesArray = jsonResponse.optJSONArray("choices");
                    if (choicesArray == null || choicesArray.length() == 0) {
                        runOnUiThread(() -> {
                            progressBar.setVisibility(View.GONE);
                            messageList.add(new Message("❌ No response from ChatGPT.", false));
                            chatAdapter.notifyItemInserted(messageList.size() - 1);
                        });
                        return;
                    }

                    JSONObject firstChoice = choicesArray.getJSONObject(0);
                    JSONObject messageObject = firstChoice.optJSONObject("message");
                    String botResponse = messageObject != null ? messageObject.optString("content", "❌ No content received.") : "❌ No content received.";

                    runOnUiThread(() -> {
                        messageList.add(new Message(botResponse.trim(), false));
                        chatAdapter.notifyItemInserted(messageList.size() - 1);
                        recyclerView.smoothScrollToPosition(messageList.size() - 1);
                        progressBar.setVisibility(View.GONE);
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(() -> {
                        progressBar.setVisibility(View.GONE);
                        messageList.add(new Message("❌ Error processing chatbot response.", false));
                        chatAdapter.notifyItemInserted(messageList.size() - 1);
                    });
                }
            }
        });
    }


}
