package com.example.myapplication;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public class CrClCalculatorActivity extends AppCompatActivity {

    private EditText etName, etAge, etWeight, etSerumCreatinine;
    private RadioGroup rgGender;
    private Button btnCalculate;
    private DatabaseReference databaseReference;
    private FirebaseUser currentUser;
    private static final String CALCULATIONS_NODE = "calculations";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crcl_calculator);

        initializeViews();
        initializeFirebase();

        btnCalculate.setOnClickListener(v -> calculateCrCl());
    }

    private void initializeViews() {
        etName = findViewById(R.id.name_input);
        etAge = findViewById(R.id.etAge);
        etWeight = findViewById(R.id.etWeight);
        etSerumCreatinine = findViewById(R.id.etSerumCreatinine);
        rgGender = findViewById(R.id.rgGender);
        btnCalculate = findViewById(R.id.btnCalculate);
    }

    private void initializeFirebase() {
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference(CALCULATIONS_NODE);
    }

    private void calculateCrCl() {
        String name = etName.getText().toString().trim();
        String ageStr = etAge.getText().toString().trim();
        String weightStr = etWeight.getText().toString().trim();
        String serumCreatinineStr = etSerumCreatinine.getText().toString().trim();

        if (!validateInputs(name, ageStr, weightStr, serumCreatinineStr)) return;

        try {
            int age = Integer.parseInt(ageStr);
            double weight = Double.parseDouble(weightStr);
            double serumCreatinine = Double.parseDouble(serumCreatinineStr);

            if (!validateClinicalValues(age, weight, serumCreatinine)) return;

            showResults(name, age, weight, serumCreatinine);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input values", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateInputs(String name, String age, String weight, String serumCreatinine) {
        if (name.isEmpty() || age.isEmpty() || weight.isEmpty() || serumCreatinine.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean validateClinicalValues(int age, double weight, double serumCreatinine) {
        if (age < 18 || age > 120) {
            Toast.makeText(this, "Age must be 18-120 years", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (weight < 30 || weight > 300) {
            Toast.makeText(this, "Weight must be 30-300 kg", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (serumCreatinine <= 0 || serumCreatinine > 10) {
            Toast.makeText(this, "Creatinine must be 0.1-10 mg/dL", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (rgGender.getCheckedRadioButtonId() == -1) {
            Toast.makeText(this, "Please select gender", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void showResults(String name, int age, double weight, double serumCreatinine) {
        boolean isMale = rgGender.getCheckedRadioButtonId() == R.id.rbMale;
        double kFactor = isMale ? 1.0 : 0.85;

        double crCl = ((140 - age) * weight * kFactor) / (72 * serumCreatinine);
        crCl = Math.round(crCl * 100.0) / 100.0;

        String[] interpretation = interpretCrClResults(crCl);
        String stage = getCkdStage(crCl);

        String resultText = String.format(Locale.getDefault(),
                "Patient: %s\nAge: %d\nWeight: %.1f kg\nSCr: %.2f mg/dL\nGender: %s\n\n" +
                        "Creatinine Clearance: %.2f mL/min\nCKD Stage: %s\n\n" +
                        "Interpretation: %s\n\nRecommendations:\n%s\n\n" +
                        "Note: Results based on Cockcroft-Gault formula.",
                name, age, weight, serumCreatinine, isMale ? "Male" : "Female", crCl, stage,
                interpretation[0], interpretation[1]);

        showResultsDialog(resultText, crCl);

        if (currentUser != null) {
            saveCalculationToDatabase(name, age, weight, serumCreatinine, isMale, crCl, stage, interpretation[0]);
        }
    }

    private void showResultsDialog(String resultText, double crCl) {
        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_results);
        dialog.setCancelable(true);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        TextView tvResult = dialog.findViewById(R.id.tvDialogResult);
        Button btnClose = dialog.findViewById(R.id.btnClose);
        BarChart chart = dialog.findViewById(R.id.chart);

        tvResult.setText(resultText);
        setupCrClChart(chart, crCl);

        btnClose.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    private void setupCrClChart(BarChart chart, double crCl) {
        ArrayList<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(0f, 120f));
        entries.add(new BarEntry(1f, 90f));
        entries.add(new BarEntry(2f, 60f));
        entries.add(new BarEntry(3f, 30f));
        entries.add(new BarEntry(4f, 15f));
        entries.add(new BarEntry(5f, 5f));
        entries.add(new BarEntry(6f, (float) crCl));

        BarDataSet dataSet = new BarDataSet(entries, "CrCl Values");
        dataSet.setColors(new int[]{
                Color.parseColor("#4CAF50"),
                Color.parseColor("#8BC34A"),
                Color.parseColor("#CDDC39"),
                Color.parseColor("#FFC107"),
                Color.parseColor("#FF9800"),
                Color.parseColor("#F44336"),
                Color.parseColor("#2196F3")
        });

        dataSet.setValueTextSize(10f);
        dataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.getDefault(), "%.0f", value);
            }
        });

        BarData data = new BarData(dataSet);
        data.setBarWidth(0.4f);

        chart.setData(data);
        chart.getDescription().setEnabled(false);
        chart.setDrawValueAboveBar(true);
        chart.setPinchZoom(false);
        chart.setDoubleTapToZoomEnabled(false);
        chart.setDrawGridBackground(false);
        chart.getLegend().setEnabled(false);

        XAxis xAxis = chart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);
        xAxis.setTextSize(10f);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(new String[]{
                "Normal", "Stage 1", "Stage 2", "Stage 3", "Stage 4", "Stage 5", "You"
        }));

        YAxis leftAxis = chart.getAxisLeft();
        leftAxis.setAxisMinimum(0f);
        leftAxis.setAxisMaximum(130f);
        leftAxis.setGranularity(20f);
        leftAxis.setTextSize(10f);
        leftAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.getDefault(), "%.0f mL/min", value);
            }
        });

        chart.getAxisRight().setEnabled(false);
        chart.animateY(1000);
        chart.invalidate();
    }

    private String[] interpretCrClResults(double crCl) {
        if (crCl >= 90) return new String[]{"Normal kidney function", "Routine monitoring, good hydration, review medications"};
        else if (crCl >= 60) return new String[]{"Mild impairment", "Monitor 6–12 months, adjust meds, control BP/DM"};
        else if (crCl >= 30) return new String[]{"Moderate impairment", "Refer to nephrologist, dose adjust, monitor"};
        else if (crCl >= 15) return new String[]{"Severe impairment", "Urgent referral, consider dialysis prep"};
        else return new String[]{"Kidney failure", "Dialysis/transplant required, emergency care needed"};
    }

    private String getCkdStage(double crCl) {
        if (crCl >= 90) return "Stage 1 (Normal)";
        else if (crCl >= 60) return "Stage 2 (Mild)";
        else if (crCl >= 30) return "Stage 3 (Moderate)";
        else if (crCl >= 15) return "Stage 4 (Severe)";
        else return "Stage 5 (Failure)";
    }

    private void saveCalculationToDatabase(String name, int age, double weight,
                                           double serumCreatinine, boolean isMale,
                                           double crCl, String ckdStage, String interpretation) {
        SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault());
        isoFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        String timestamp = isoFormat.format(new Date());

        Map<String, Object> record = new HashMap<>();
        record.put("patientName", name);
        record.put("age", age);
        record.put("weightKg", weight);
        record.put("serumCreatinine", serumCreatinine);
        record.put("gender", isMale ? "Male" : "Female");
        record.put("crCl", crCl);
        record.put("ckdStage", ckdStage);
        record.put("interpretation", interpretation);
        record.put("timestamp", timestamp);

        String uid = currentUser.getUid();
        String recordId = databaseReference.child(uid).child("records").push().getKey();

        if (recordId != null) {
            databaseReference.child(uid).child("records").child(recordId)
                    .setValue(record)
                    .addOnSuccessListener(aVoid ->
                            Toast.makeText(this, "Calculation saved", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Failed to save", Toast.LENGTH_SHORT).show());
        }
    }
}
