package com.example.myapplication;

public class PainMedication {
    private String name;
    private String drugClass;
    private String route;
    private String onset;
    private String duration;
    private String dosage;
    private String considerations;
    private String category;
    private String mechanism;
    private String sideEffects;

    public PainMedication(String name, String drugClass, String route, String onset, String duration,
                          String dosage, String considerations, String category, String mechanism,
                          String sideEffects) {
        this.name = name;
        this.drugClass = drugClass;
        this.route = route;
        this.onset = onset;
        this.duration = duration;
        this.dosage = dosage;
        this.considerations = considerations;
        this.category = category;
        this.mechanism = mechanism;
        this.sideEffects = sideEffects;
    }

    // Getters
    public String getName() { return name; }
    public String getDrugClass() { return drugClass; }
    public String getRoute() { return route; }
    public String getOnset() { return onset; }
    public String getDuration() { return duration; }
    public String getDosage() { return dosage; }
    public String getConsiderations() { return considerations; }
    public String getCategory() { return category; }
    public String getMechanism() { return mechanism; }
    public String getSideEffects() { return sideEffects; }
}