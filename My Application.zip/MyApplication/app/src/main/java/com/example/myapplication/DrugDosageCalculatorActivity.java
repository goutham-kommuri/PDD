package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class DrugDosageCalculatorActivity extends AppCompatActivity {

    private EditText etAge, etWeight, etHeight, etName;
    private RadioGroup radioGender;
    private Spinner spinnerDrugs;
    private Button btnCalculate;
    private TextView tvResult;

    private String[] drugs = {
            "Propofol", "Etomidate", "Ketamine", "Succinylcholine", "Rocuronium",
            "Vecuronium", "Morphine", "Fentanyl", "Remifentanil", "Cefazolin",
            "Clindamycin", "Ondansetron", "Dexamethasone", "Sugammadex",
            "Neostigmine", "Epinephrine", "Norepinephrine", "Dopamine",
            "Phenylephrine", "Heparin", "Enoxaparin", "Normal Saline", "Lactated Ringer's",
            "Atropine", "Lidocaine", "Hydrocortisone", "Calcium Chloride",
            "Sodium Bicarbonate", "Vasopressin", "Amiodarone",
            "Midazolam", "Glycopyrrolate", "Esmolol", "Magnesium Sulfate",
            "Tranexamic Acid", "Metoprolol", "Flumazenil"
    };

    // Firebase
    private DatabaseReference databaseReference;
    private FirebaseUser currentUser;
    private static final String CALCULATIONS_NODE = "calculations";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drug_dosage_calculator);

        // UI Customization
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        getWindow().setStatusBarColor(getResources().getColor(android.R.color.white));
        getWindow().setNavigationBarColor(getResources().getColor(android.R.color.white));

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // Initialize UI components
        etName = findViewById(R.id.name_input);
        etAge = findViewById(R.id.etAge);
        etWeight = findViewById(R.id.etWeight);
        etHeight = findViewById(R.id.etHeight);
        radioGender = findViewById(R.id.radioGender);
        spinnerDrugs = findViewById(R.id.spinnerDrugs);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);

        // Initialize Firebase
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference(CALCULATIONS_NODE);

        // Set up spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, drugs);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDrugs.setAdapter(adapter);

        btnCalculate.setOnClickListener(v -> calculateDosage());
    }

    private void calculateDosage() {
        String name = etName.getText().toString().trim();
        String ageStr = etAge.getText().toString().trim();
        String weightStr = etWeight.getText().toString().trim();
        String heightStr = etHeight.getText().toString().trim();

        // Validate inputs
        if (name.isEmpty() || ageStr.isEmpty() || weightStr.isEmpty() || heightStr.isEmpty()) {
            tvResult.setText("Please fill in all fields.");
            return;
        }

        try {
            int age = Integer.parseInt(ageStr);
            double weight = Double.parseDouble(weightStr);
            double heightInCm = Double.parseDouble(heightStr);
            double height = heightInCm / 100.0; // convert cm to meters

            // Determine gender
            boolean isFemale = radioGender.getCheckedRadioButtonId() == R.id.radioFemale;
            String gender = isFemale ? "Female" : "Male";

            // Calculate BMI
            double bmi = weight / (height * height);

            // Calculate Lean Body Mass (LBM) using Boer formula
            double lbm;
            if (isFemale) {
                lbm = (0.252 * weight) + (0.473 * heightInCm) - 48.3;
            } else {
                lbm = (0.407 * weight) + (0.267 * heightInCm) - 19.2;
            }
            if (lbm < (0.7 * weight)) {
                lbm = weight;
            }

            // Get the selected drug from spinner
            String selectedDrug = spinnerDrugs.getSelectedItem().toString();
            String result = calculateDrugDosage(selectedDrug, age, weight, heightInCm, bmi, lbm, isFemale);
            tvResult.setText(result);

            // Save to database
            if (currentUser != null) {
                saveCalculationToDatabase(
                        currentUser.getUid(),
                        name,
                        age,
                        weight,
                        heightInCm,
                        gender,
                        selectedDrug,
                        result,
                        bmi,
                        lbm
                );
            } else {
                Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show();
            }

        } catch (NumberFormatException e) {
            tvResult.setText("Invalid input values.");
        }
    }

    private String calculateDrugDosage(String selectedDrug, int age, double weight, double heightInCm,
                                       double bmi, double lbm, boolean isFemale) {
        String result;
        switch (selectedDrug) {
            case "Propofol":
                result = "Propofol: " + String.format("%.2f", 2 * weight) + " mg IV (Induction dose)";
                if (age < 18) result += "\nPediatric: Use 2.5–3.5 mg/kg IV, titrate cautiously.";
                if (age > 65) result += "\nElderly (>65): Reduce to 1–1.5 mg/kg IV, start low (e.g., 20–50 mg) and titrate slowly due to hypotension and respiratory depression risk.";
                else if (bmi > 30) result += "\nObese: Consider 1.5 mg/kg LBM to avoid overdose.";
                break;
            case "Etomidate":
                result = "Etomidate: " + String.format("%.2f", 0.3 * weight) + " mg IV (Induction dose)";
                if (age < 18) result += "\nPediatric: 0.2–0.3 mg/kg IV, monitor adrenal suppression.";
                if (age > 65) result += "\nElderly (>65): Reduce to 0.15–0.2 mg/kg IV (e.g., 10–15 mg), cautious titration for hypotension and adrenal suppression.";
                break;
            case "Ketamine":
                result = "Ketamine: " + String.format("%.2f", 1.5 * weight) + " mg IV (Induction dose)";
                if (age < 18) result += "\nPediatric: 1–2 mg/kg IV, higher doses may be tolerated.";
                if (age > 65) result += "\nElderly (>65): Reduce to 0.5–1 mg/kg IV (e.g., 25–50 mg), monitor for hypertension or emergence reactions.";
                break;
            case "Succinylcholine":
                result = "Succinylcholine: " + String.format("%.2f", 1.5 * weight) + " mg IV (RSI dose)";
                if (age < 18) result += "\nPediatric: 2 mg/kg IV (higher dose due to volume distribution).";
                if (age > 65) result += "\nElderly (>65): Use 1 mg/kg LBM (e.g., 50–70 mg), avoid if renal failure or hyperkalemia risk.";
                else if (bmi > 30) result += "\nObese: Use 1 mg/kg LBM to prevent overdose.";
                break;
            case "Rocuronium":
                result = "Rocuronium: " + String.format("%.2f", 1.2 * weight) + " mg IV (RSI dose)";
                if (age < 18) result += "\nPediatric: 0.6–1.2 mg/kg IV, adjust for rapid metabolism.";
                if (age > 65) result += "\nElderly (>65): Reduce to 0.6–0.9 mg/kg LBM (e.g., 40–60 mg), prolonged effect due to slower clearance.";
                else if (bmi > 30) result += "\nObese: Use 1.2 mg/kg LBM.";
                break;
            case "Vecuronium":
                result = "Vecuronium: " + String.format("%.2f", 0.1 * weight) + " mg IV";
                if (age < 18) result += "\nPediatric: 0.1 mg/kg IV, monitor prolonged effect.";
                if (age > 65) result += "\nElderly (>65): Reduce to 0.06–0.08 mg/kg IV (e.g., 4–6 mg), adjust for hepatic/renal impairment.";
                break;
            case "Morphine":
                result = "Morphine: " + String.format("%.2f", 0.1 * weight) + " mg IV";
                if (age < 18) result += "\nPediatric: 0.05–0.1 mg/kg IV, titrate for respiratory depression.";
                if (age > 65) result += "\nElderly (>65): Reduce to 0.02–0.05 mg/kg IV (e.g., 1–3 mg), slow titration due to renal decline and respiratory risk.";
                break;
            case "Fentanyl":
                result = "Fentanyl: " + String.format("%.2f", 2 * weight) + " mcg IV";
                if (age < 18) result += "\nPediatric: 1–2 mcg/kg IV, monitor apnea.";
                if (age > 65) result += "\nElderly (>65): Reduce to 0.5–1 mcg/kg IV (e.g., 25–50 mcg), high sensitivity, monitor respiratory depression.";
                break;
            case "Remifentanil":
                result = "Remifentanil: Start at " + String.format("%.2f", 0.1 * weight) + " mcg/kg/min infusion";
                if (age < 18) result += "\nPediatric: 0.05–0.1 mcg/kg/min, titrate rapidly.";
                if (age > 65) result += "\nElderly (>65): Start at 0.025–0.05 mcg/kg/min (e.g., 1–3 mcg/min for 60 kg), reduce due to slower metabolism.";
                break;
            case "Cefazolin":
                result = (weight < 120) ? "Cefazolin: 2000 mg IV" : "Cefazolin: 3000 mg IV";
                if (age < 18) result += "\nPediatric: 25–50 mg/kg IV (max 2 g).";
                if (age > 65) result += "\nElderly (>65): 1–2 g IV, reduce dose if CrCl < 30 mL/min (e.g., 1 g q12h), monitor renal function.";
                break;
            case "Clindamycin":
                result = "Clindamycin: 600 mg IV";
                if (age < 18) result += "\nPediatric: 10 mg/kg IV (max 600 mg).";
                if (age > 65) result += "\nElderly (>65): 300–600 mg IV, adjust if severe hepatic impairment present.";
                break;
            case "Ondansetron":
                result = "Ondansetron: 4 mg IV";
                if (age < 18) result += "\nPediatric: 0.1 mg/kg IV (max 4 mg).";
                if (age > 65) result += "\nElderly (>65): 4 mg IV, no adjustment unless severe hepatic impairment (max 8 mg/day).";
                break;
            case "Dexamethasone":
                result = "Dexamethasone: 8 mg IV";
                if (age < 18) result += "\nPediatric: 0.15 mg/kg IV (max 8 mg).";
                if (age > 65) result += "\nElderly (>65): 4–8 mg IV, use 4 mg if frail or diabetic, monitor glucose and BP.";
                break;
            case "Sugammadex":
                result = "Sugammadex: " + String.format("%.2f", 2 * weight) + " mg IV";
                if (age < 18) result += "\nPediatric: 2 mg/kg IV, limited data.";
                if (age > 65) result += "\nElderly (>65): 1–2 mg/kg TBW (e.g., 70–140 mg for 70 kg), monitor renal function (CrCl < 30 delays clearance).";
                break;
            case "Neostigmine":
                result = "Neostigmine: " + String.format("%.2f", 0.05 * weight) + " mg IV\n" +
                        "Glycopyrrolate: " + String.format("%.2f", 0.01 * weight) + " mg IV";
                if (age < 18) result += "\nPediatric: 0.03–0.05 mg/kg IV, titrate.";
                if (age > 65) result += "\nElderly (>65): 0.02–0.04 mg/kg IV (max 5 mg, e.g., 1.5–3 mg), reduce if renal impairment, monitor bradycardia.";
                break;
            case "Epinephrine":
                result = "Epinephrine Bolus: 10–50 mcg IV (titrate to response)";
                if (age < 18) result += "\nPediatric: 0.1 mcg/kg IV bolus (max 10 mcg).";
                if (age > 65) result += "\nElderly (>65): 5–10 mcg IV bolus, slow push, monitor for arrhythmia or ischemia.";
                break;
            case "Norepinephrine":
                result = "Norepinephrine: Start at 0.05 mcg/kg/min infusion";
                if (age < 18) result += "\nPediatric: 0.05–0.1 mcg/kg/min, titrate.";
                if (age > 65) result += "\nElderly (>65): Start at 0.01–0.03 mcg/kg/min (e.g., 0.6–1.8 mcg/min for 60 kg), avoid high doses due to vasoconstriction risk.";
                break;
            case "Dopamine":
                result = "Dopamine: Start at 5 mcg/kg/min infusion";
                if (age < 18) result += "\nPediatric: 2–10 mcg/kg/min, titrate for effect.";
                if (age > 65) result += "\nElderly (>65): Start at 1–3 mcg/kg/min (e.g., 60–180 mcg/min for 60 kg), monitor renal function and arrhythmia.";
                break;
            case "Phenylephrine":
                result = "Phenylephrine Bolus: 50-100 mcg IV (adjust per patient response)";
                if (age < 18) result += "\nPediatric: 1 mcg/kg IV (max 50 mcg).";
                if (age > 65) result += "\nElderly (>65): 25–50 mcg IV, slow bolus, watch for reflex bradycardia or hypertension.";
                break;
            case "Heparin":
                result = "Heparin: 5000 units subQ prophylaxis";
                if (age < 18) result += "\nPediatric: 100 units/kg subQ (max 5000 units).";
                if (age > 65) result += "\nElderly (>65): 2500–5000 units subQ, consider 50–70 units/kg IV if therapeutic, monitor bleeding risk.";
                break;
            case "Enoxaparin":
                result = (bmi <= 40) ? "Enoxaparin: 40 mg subQ" : "Enoxaparin: " + String.format("%.2f", 0.5 * weight) + " mg subQ (BMI > 40)";
                if (age < 18) result += "\nPediatric: 0.5 mg/kg subQ q12h (prophylaxis).";
                if (age > 65) result += "\nElderly (>65): 30 mg subQ daily if CrCl < 30 mL/min, or 0.4 mg/kg if obese, monitor anti-Xa levels.";
                break;
            case "Normal Saline":
                result = "Normal Saline: " + String.format("%.2f", 30 * weight) + " mL IV bolus";
                if (age < 18) result += "\nPediatric: 20 mL/kg IV, reassess.";
                if (age > 65) result += "\nElderly (>65): 5–10 mL/kg IV (e.g., 300–600 mL for 60 kg), cautious bolus to avoid fluid overload or heart failure.";
                break;
            case "Lactated Ringer's":
                result = "Lactated Ringer's: " + String.format("%.2f", 30 * weight) + " mL IV bolus";
                if (age < 18) result += "\nPediatric: 20 mL/kg IV, reassess.";
                if (age > 65) result += "\nElderly (>65): 5–10 mL/kg IV (e.g., 300–600 mL for 60 kg), monitor for fluid overload and electrolyte imbalance.";
                break;
            case "Atropine":
                result = "Atropine: 0.5 mg IV q3–5 min (max 3 mg)";
                if (age < 18) result += "\nPediatric: 0.02 mg/kg IV (min 0.1 mg, max 0.5 mg).";
                if (age > 65) result += "\nElderly (>65): 0.25–0.5 mg IV q5 min (max 3 mg), risk of tachycardia or confusion, titrate slowly.";
                break;
            case "Lidocaine":
                result = "Lidocaine: " + String.format("%.2f", 1.5 * weight) + " mg IV bolus";
                if (age < 18) result += "\nPediatric: 1 mg/kg IV (max 100 mg).";
                if (age > 65) result += "\nElderly (>65): 0.5–1 mg/kg IV (e.g., 30–60 mg for 60 kg), reduce dose, monitor for CNS toxicity.";
                break;
            case "Hydrocortisone":
                result = "Hydrocortisone: 100 mg IV";
                if (age < 18) result += "\nPediatric: 2 mg/kg IV (max 100 mg).";
                if (age > 65) result += "\nElderly (>65): 50–100 mg IV, start at 50 mg if frail, monitor glucose and BP.";
                break;
            case "Calcium Chloride":
                result = "Calcium Chloride: 1 g IV (10 mL of 10% solution)";
                if (age < 18) result += "\nPediatric: 20 mg/kg IV (max 1 g).";
                if (age > 65) result += "\nElderly (>65): 0.5–1 g IV slow push, monitor for hypercalcemia or bradycardia.";
                break;
            case "Sodium Bicarbonate":
                result = "Sodium Bicarbonate: " + String.format("%.2f", weight) + " mEq IV";
                if (age < 18) result += "\nPediatric: 1 mEq/kg IV, dilute 1:1.";
                if (age > 65) result += "\nElderly (>65): 0.5 mEq/kg IV (e.g., 30 mEq for 60 kg), slow infusion, risk of alkalosis or fluid overload.";
                break;
            case "Vasopressin":
                result = "Vasopressin: 40 units IV";
                if (age < 18) result += "\nPediatric: 0.3 units/kg IV (max 40 units).";
                if (age > 65) result += "\nElderly (>65): 20–40 units IV, start at 20 units, monitor coronary perfusion and hypertension.";
                break;
            case "Amiodarone":
                result = "Amiodarone: 150 mg IV over 10 min";
                if (age < 18) result += "\nPediatric: 5 mg/kg IV over 20–60 min (max 150 mg).";
                if (age > 65) result += "\nElderly (>65): 75–150 mg IV over 10–20 min, reduce if hypotensive, monitor bradycardia or QT prolongation.";
                break;
            case "Midazolam":
                result = "Midazolam: 1–2 mg IV (Sedation dose)";
                if (age < 18) result += "\nPediatric: 0.05–0.1 mg/kg IV (max 2 mg).";
                if (age > 65) result += "\nElderly (>65): 0.5–1 mg IV slow push, high risk of oversedation and respiratory depression.";
                break;
            case "Glycopyrrolate":
                result = "Glycopyrrolate: 0.2 mg IV";
                if (age < 18) result += "\nPediatric: 0.004 mg/kg IV (max 0.2 mg).";
                if (age > 65) result += "\nElderly (>65): 0.1–0.2 mg IV, start at 0.1 mg if frail, monitor tachycardia or urinary retention.";
                break;
            case "Esmolol":
                result = "Esmolol: " + String.format("%.2f", 0.5 * weight) + " mg IV over 1 min";
                if (age < 18) result += "\nPediatric: 0.5 mg/kg IV, titrate.";
                if (age > 65) result += "\nElderly (>65): 0.25–0.5 mg/kg IV (e.g., 15–30 mg for 60 kg), slow bolus, monitor hypotension or bradycardia.";
                break;
            case "Magnesium Sulfate":
                result = "Magnesium Sulfate: 2 g IV over 10–20 min";
                if (age < 18) result += "\nPediatric: 25–50 mg/kg IV (max 2 g).";
                if (age > 65) result += "\nElderly (>65): 1–2 g IV over 20 min, reduce to 1 g if renal impairment (CrCl < 30), monitor reflexes.";
                break;
            case "Tranexamic Acid":
                result = "Tranexamic Acid: 1 g IV over 10 min";
                if (age < 18) result += "\nPediatric: 10 mg/kg IV (max 1 g).";
                if (age > 65) result += "\nElderly (>65): 0.5–1 g IV over 10–20 min, reduce if renal impairment (CrCl < 50), monitor thrombosis.";
                break;
            case "Metoprolol":
                result = "Metoprolol: 2.5–5 mg IV (titrate to response)";
                if (age < 18) result += "\nPediatric: 0.1 mg/kg IV (max 5 mg).";
                if (age > 65) result += "\nElderly (>65): 1–2.5 mg IV slow push, titrate every 5–10 min, monitor bradycardia or hypotension.";
                break;
            case "Flumazenil":
                result = "Flumazenil: 0.2 mg IV q1 min (max 1 mg)";
                if (age < 18) result += "\nPediatric: 0.01 mg/kg IV q1 min (max 0.2 mg/dose).";
                if (age > 65) result += "\nElderly (>65): 0.1 mg IV q1–2 min (max 1 mg), slow titration, high risk of seizures or agitation.";
                break;
            default:
                result = "Dosage calculation for " + selectedDrug + " is not available.";
        }
        return result;
    }

    private void saveCalculationToDatabase(String userId, String name, int age, double weight,
                                           double heightInCm, String gender, String drugName,
                                           String dosageResult, double bmi, double lbm) {
        // Generate ISO 8601 timestamp
        SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        isoFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        String timestamp = isoFormat.format(new Date());

        // Create record data
        Map<String, Object> record = new HashMap<>();
        record.put("patientName", name);
        record.put("age", age);
        record.put("weightKg", weight);
        record.put("heightCm", heightInCm);
        record.put("gender", gender);
        record.put("drugName", drugName);
        record.put("dosageResult", dosageResult);
        record.put("bmi", bmi);
        record.put("lbm", lbm);
        record.put("timestamp", timestamp);

        // Save to user's drugdosage node
        String recordId = databaseReference.child(userId).child("drugdosage").push().getKey();

        if (recordId != null) {
            databaseReference.child(userId).child("drugdosage").child(recordId)
                    .setValue(record)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Calculation saved", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(this, "Save failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }
    }
}