package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class PainMedicationAdapter extends RecyclerView.Adapter<PainMedicationAdapter.ViewHolder> {
    private List<PainMedication> medicationList;

    public PainMedicationAdapter(List<PainMedication> medicationList) {
        this.medicationList = medicationList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_pain_medication, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PainMedication medication = medicationList.get(position);

        holder.medicationName.setText(medication.getName());
        holder.medicationClass.setText(medication.getDrugClass());
        holder.medicationRoute.setText(medication.getRoute());
        holder.medicationMechanism.setText("Mechanism: " + medication.getMechanism());
        holder.medicationOnset.setText("Onset: " + medication.getOnset());
        holder.medicationDuration.setText("Duration: " + medication.getDuration());
        holder.medicationDosage.setText("Dosage: " + medication.getDosage());
        holder.medicationSideEffects.setText("Side Effects: " + medication.getSideEffects());
        holder.medicationConsiderations.setText("Special Considerations: " + medication.getConsiderations());
    }

    @Override
    public int getItemCount() {
        return medicationList.size();
    }

    public void updateList(List<PainMedication> newList) {
        medicationList = newList;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView medicationName, medicationClass, medicationRoute, medicationMechanism,
                medicationOnset, medicationDuration, medicationDosage, medicationSideEffects,
                medicationConsiderations;

        ViewHolder(View itemView) {
            super(itemView);
            medicationName = itemView.findViewById(R.id.medicationName);
            medicationClass = itemView.findViewById(R.id.medicationClass);
            medicationRoute = itemView.findViewById(R.id.medicationRoute);
            medicationMechanism = itemView.findViewById(R.id.medicationMechanism);
            medicationOnset = itemView.findViewById(R.id.medicationOnset);
            medicationDuration = itemView.findViewById(R.id.medicationDuration);
            medicationDosage = itemView.findViewById(R.id.medicationDosage);
            medicationSideEffects = itemView.findViewById(R.id.medicationSideEffects);
            medicationConsiderations = itemView.findViewById(R.id.medicationConsiderations);
        }
    }
}