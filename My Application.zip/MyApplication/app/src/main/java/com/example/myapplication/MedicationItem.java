package com.example.myapplication;

public class MedicationItem {
    private final String name;
    private final String drugClass;
    private final String route;
    private final String onset;
    private final String duration;
    private final String dosage;
    private final String considerations;
    private final String category;

    public MedicationItem(String name, String drugClass, String route, String onset,
                          String duration, String dosage, String considerations,
                          String category) {
        this.name = name;
        this.drugClass = drugClass;
        this.route = route;
        this.onset = onset;
        this.duration = duration;
        this.dosage = dosage;
        this.considerations = considerations;
        this.category = category;
    }

    public String getName() { return name; }
    public String getDrugClass() { return drugClass; }
    public String getRoute() { return route; }
    public String getOnset() { return onset; }
    public String getDuration() { return duration; }
    public String getDosage() { return dosage; }
    public String getConsiderations() { return considerations; }
    public String getCategory() { return category; }
}