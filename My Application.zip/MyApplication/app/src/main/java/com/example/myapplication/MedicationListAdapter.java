package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MedicationListAdapter extends RecyclerView.Adapter<MedicationListAdapter.MedicationViewHolder> {
    private List<MedicationItem> medicationItems;

    public MedicationListAdapter(List<MedicationItem> medicationItems) {
        this.medicationItems = medicationItems;
    }

    @NonNull
    @Override
    public MedicationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_antibiotic_table, parent, false);
        return new MedicationViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicationViewHolder holder, int position) {
        MedicationItem currentItem = medicationItems.get(position);

        holder.medicationNameView.setText(currentItem.getName());
        holder.medicationClassView.setText(currentItem.getDrugClass());
        holder.administrationRouteView.setText(currentItem.getRoute());
        holder.onsetTimeView.setText("Onset: " + currentItem.getOnset());
        holder.durationView.setText("Duration: " + currentItem.getDuration());
        holder.dosageView.setText("Dosage: " + currentItem.getDosage());
        holder.specialNotesView.setText("Special Considerations: " + currentItem.getConsiderations());
    }

    @Override
    public int getItemCount() {
        return medicationItems.size();
    }

    public void updateMedicationList(List<MedicationItem> newItems) {
        medicationItems = newItems;
        notifyDataSetChanged();
    }

    static class MedicationViewHolder extends RecyclerView.ViewHolder {
        TextView medicationNameView, medicationClassView, administrationRouteView,
                onsetTimeView, durationView, dosageView, specialNotesView;

        MedicationViewHolder(View itemView) {
            super(itemView);
            medicationNameView = itemView.findViewById(R.id.antibioticName);
            medicationClassView = itemView.findViewById(R.id.antibioticClass);
            administrationRouteView = itemView.findViewById(R.id.antibioticRoute);
            onsetTimeView = itemView.findViewById(R.id.antibioticOnset);
            durationView = itemView.findViewById(R.id.antibioticDuration);
            dosageView = itemView.findViewById(R.id.antibioticDosage);
            specialNotesView = itemView.findViewById(R.id.antibioticConsiderations);
        }
    }
}