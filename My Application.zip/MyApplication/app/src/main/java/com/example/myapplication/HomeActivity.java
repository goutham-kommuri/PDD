package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.firebase.auth.FirebaseAuth;
import com.tbuonomo.viewpagerdotsindicator.WormDotsIndicator;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {
    private static final long SLIDE_DELAY = 3000; // 3 seconds delay between slides
    private static final long SLIDE_PERIOD = 3000; // 3 seconds period for sliding
    private Handler sliderHandler;
    private Runnable sliderRunnable;
    private FirebaseAuth mAuth;
    private SharedPreferences sharedPreferences;
    private TextView userGreeting;
    private ImageView logoutButton;
    private CardView cardBMI, cardCRCL, cardDrugDosage, cardPediatricDose;
    private ViewPager2 viewPager;
    private WormDotsIndicator dotsIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ImageView historyButton = findViewById(R.id.historyButton);
        mAuth = FirebaseAuth.getInstance();
        sharedPreferences = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE);

        // Initialize UI Elements
        userGreeting = findViewById(R.id.userGreeting);
        logoutButton = findViewById(R.id.logoutButton);
        cardBMI = findViewById(R.id.cardBMI);
        cardCRCL = findViewById(R.id.cardCRCL);
        cardDrugDosage = findViewById(R.id.cardDrugDosage);
        cardPediatricDose = findViewById(R.id.cardPediatricDose);
        viewPager = findViewById(R.id.viewPager);
        dotsIndicator = findViewById(R.id.dotsIndicator);
        LinearLayout anestheticsLayout = findViewById(R.id.Anesthetics);
        LinearLayout antibioticsLayout = findViewById(R.id.Antibiotics);
        LinearLayout AnticoagulantsLayout = findViewById(R.id.Anticoagulants);
        LinearLayout PainManagementLayout = findViewById(R.id.PainManagement);
        LinearLayout iv_fluidsLayout = findViewById(R.id.iv_fluids);
        // Retrieve User's Name from SharedPreferences
        String name = sharedPreferences.getString("name", "User");
        userGreeting.setText("Hello, Dr. " + name);

        // Setup Image Slider
        setupImageSlider();

        // Hide Action Bar & Customize UI
        setupUI();
        historyButton.setOnClickListener(v -> {
            startActivity(new Intent(this, CategoryHistoryActivity.class));
        });
        // Logout Button Click
        logoutButton.setOnClickListener(v -> logoutUser());

        // Button Click Listeners
        cardBMI.setOnClickListener(v -> openActivity(BMICalculatorActivity.class));
        cardCRCL.setOnClickListener(v -> openActivity(CrClCalculatorActivity.class));
        cardDrugDosage.setOnClickListener(v -> openActivity(DrugDosageCalculatorActivity.class));

        // Pediatric Dose Click - Navigate to Pediatric Dose Calculator
        cardPediatricDose.setOnClickListener(v -> openActivity(PediatricDoseCalculatorActivity.class));

        // Anesthetics Click - Navigate to AnesthesiaActivity
        anestheticsLayout.setOnClickListener(v -> openActivity(AnesthesiaActivity.class));
        antibioticsLayout.setOnClickListener(v -> openActivity(MedicationGuideActivity.class));
        AnticoagulantsLayout.setOnClickListener(v -> openActivity(AnticoagulationActivity.class));
        PainManagementLayout.setOnClickListener(v -> openActivity(PainManagementActivity.class));
        iv_fluidsLayout.setOnClickListener(v -> openActivity(IVFluidsActivity.class));
    }



    private void setupImageSlider() {
        List<Integer> images = new ArrayList<>();
        images.add(R.drawable.image1);
        images.add(R.drawable.image2);
        images.add(R.drawable.image3);
        images.add(R.drawable.image4);

        viewPager.setAdapter(new ImageSliderAdapter(images));
        dotsIndicator.attachTo(viewPager);

        // Auto-slide functionality
        sliderHandler = new Handler(Looper.getMainLooper());
        sliderRunnable = new Runnable() {
            @Override
            public void run() {
                int currentItem = viewPager.getCurrentItem();
                int totalItems = viewPager.getAdapter().getItemCount(); // Changed from getCount()

                if (currentItem < totalItems - 1) {
                    viewPager.setCurrentItem(currentItem + 1);
                } else {
                    viewPager.setCurrentItem(0); // Go back to first item
                }

                // Schedule the next slide
                sliderHandler.postDelayed(this, SLIDE_PERIOD);
            }
        };

        // Start auto-sliding
        sliderHandler.postDelayed(sliderRunnable, SLIDE_DELAY);

        // Stop auto-sliding when user interacts with ViewPager2
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                // Reset the handler when user manually changes page
                sliderHandler.removeCallbacks(sliderRunnable);
                sliderHandler.postDelayed(sliderRunnable, SLIDE_DELAY);
            }
        });
    }

    // Clean up when the activity/fragment is destroyed
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (sliderHandler != null && sliderRunnable != null) {
            sliderHandler.removeCallbacks(sliderRunnable);
        }
    }

    private void setupUI() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        getWindow().setStatusBarColor(getResources().getColor(android.R.color.white));
        getWindow().setNavigationBarColor(getResources().getColor(android.R.color.white));

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }

    private void logoutUser() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        mAuth.signOut();
        startActivity(new Intent(HomeActivity.this, LoginActivity.class));
        finish();
    }

    private void openActivity(Class<?> activityClass) {
        Intent intent = new Intent(HomeActivity.this, activityClass);
        startActivity(intent);
    }

    // Internal Adapter for ViewPager2
    private static class ImageSliderAdapter extends RecyclerView.Adapter<ImageSliderAdapter.ImageViewHolder> {
        private final List<Integer> imageList;

        public ImageSliderAdapter(List<Integer> imageList) {
            this.imageList = imageList;
        }

        @NonNull
        @Override
        public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_slider_image, parent, false);
            return new ImageViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
            holder.imageView.setImageResource(imageList.get(position));
        }

        @Override
        public int getItemCount() {
            return imageList.size();
        }

        static class ImageViewHolder extends RecyclerView.ViewHolder {
            ImageView imageView;

            public ImageViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.imageSliderItem);
            }
        }
    }
}
