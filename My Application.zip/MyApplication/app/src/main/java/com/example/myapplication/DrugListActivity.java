package com.example.myapplication;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class DrugListActivity extends AppCompatActivity {

    private Spinner spinnerDrug;
    private EditText etInput, etAge;
    private Button btnCalculate;
    private TextView tvResult;
    private RadioGroup radioGroup;
    private RadioButton radioWeight;
    private final DecimalFormat df = new DecimalFormat("0.00");

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.antipyretic);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        initializeViews();
        setupDrugSpinner();
        setupCalculateButton();
    }

    private void initializeViews() {
        spinnerDrug = findViewById(R.id.spinnerDrug);
        etInput = findViewById(R.id.etInput);
        etAge = findViewById(R.id.etAge);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);
        radioGroup = findViewById(R.id.radioGroup);
        radioWeight = findViewById(R.id.radioWeight);
    }

    private void setupDrugSpinner() {
        String[] drugs = {
                "Paracetamol Oral Drops (100mg/ml)",
                "Paracetamol Syrup (120mg/5ml)",
                "Paracetamol Syrup (125mg/5ml)",
                "Paracetamol Syrup (250mg/5ml)",
                "Paracetamol Suppository",
                "Ibuprofen Oral Drops (40mg/ml)",
                "Ibuprofen Suspension (100mg/5ml)",
                "Diclofenac Suppository (12.5mg/25mg)"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, drugs);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDrug.setAdapter(adapter);
    }

    private void setupCalculateButton() {
        btnCalculate.setOnClickListener(v -> {
            try {
                calculateDose();
            } catch (Exception e) {
                showToast("Calculation error: " + e.getMessage());
            }
        });
    }

    private void calculateDose() {
        String selectedDrug = spinnerDrug.getSelectedItem().toString();
        String inputText = etInput.getText().toString().trim();
        String ageText = etAge.getText().toString().trim();

        if (inputText.isEmpty()) {
            showToast("Please enter weight/age");
            return;
        }

        double inputValue = parseInputValue(inputText);
        if (inputValue <= 0) {
            showToast("Value must be positive");
            return;
        }

        int age = ageText.isEmpty() ? -1 : Integer.parseInt(ageText);
        boolean isWeightBased = radioWeight.isChecked();

        String result = generateDosingRecommendation(selectedDrug, inputValue, age, isWeightBased);
        tvResult.setText(result);

        saveCalculationToDatabase(selectedDrug, inputValue, age, isWeightBased, result);
    }

    private void saveCalculationToDatabase(String drug, double value, int age, boolean isWeightBased, String result) {
        if (mAuth.getCurrentUser() == null) {
            showToast("Not logged in - calculation won't be saved");
            return;
        }

        String uid = mAuth.getCurrentUser().getUid();
        DatabaseReference userCalculationsRef = mDatabase.child("calculations")
                .child(uid)
                .child("antipyretic");

        String calculationId = userCalculationsRef.push().getKey();

        Map<String, Object> calculationData = new HashMap<>();
        calculationData.put("drug", drug);
        calculationData.put("value", value);
        calculationData.put("age", age);
        calculationData.put("isWeightBased", isWeightBased);
        calculationData.put("result", result);
        calculationData.put("timestamp", System.currentTimeMillis());

        if (calculationId != null) {
            userCalculationsRef.child(calculationId).setValue(calculationData)
                    .addOnSuccessListener(aVoid -> showToast("Calculation saved to history"))
                    .addOnFailureListener(e -> showToast("Failed to save calculation"));
        }
    }

    private void handleIbuprofen(StringBuilder sb, double value, int age, boolean isWeightBased,
                                 double mgPerUnit, double mlPerUnit) {
        if (!isWeightBased) {
            sb.append("Ibuprofen requires weight-based dosing\n");
            return;
        }

        if (age >= 0 && age < 6) {
            sb.append("⚠️ Contraindicated in infants <6 months\n");
            return;
        }

        double doseMg = Math.min(value * 7.5, 400);
        double doseMl = (doseMg/mgPerUnit)*mlPerUnit;

        sb.append(String.format("Standard dose: %s mg (%s ml) Q6-8H\n",
                df.format(doseMg), df.format(doseMl)));
        sb.append(String.format("MAX %s mg/day (%s mg/kg/day)\n",
                df.format(value*40), df.format(40)));

        sb.append("\nCLINICAL NOTES:\n");
        sb.append("• Avoid in dehydration/renal impairment\n");
        sb.append("• Contraindicated in chickenpox\n");
        sb.append("• Stop 3 days before surgery\n");
    }

    private String generateDosingRecommendation(String drug, double value, int age, boolean isWeightBased) {
        StringBuilder sb = new StringBuilder();

        switch (drug) {
            case "Paracetamol Oral Drops (100mg/ml)":
                handleParacetamol(sb, value, age, isWeightBased, 100, 1);
                break;
            case "Paracetamol Syrup (120mg/5ml)":
                handleParacetamol(sb, value, age, isWeightBased, 120, 5);
                break;
            case "Paracetamol Syrup (125mg/5ml)":
                handleParacetamol(sb, value, age, isWeightBased, 125, 5);
                break;
            case "Paracetamol Syrup (250mg/5ml)":
                handleParacetamol(sb, value, age, isWeightBased, 250, 5);
                break;
            case "Paracetamol Suppository":
                handleParacetamolSuppository(sb, value, age, isWeightBased);
                break;
            case "Ibuprofen Oral Drops (40mg/ml)":
                handleIbuprofen(sb, value, age, isWeightBased, 40, 1);
                break;
            case "Ibuprofen Suspension (100mg/5ml)":
                handleIbuprofen(sb, value, age, isWeightBased, 100, 5);
                break;
            case "Diclofenac Suppository (12.5mg/25mg)":
                handleDiclofenac(sb, value, age, isWeightBased);
                break;
            default:
                sb.append("Consult specialist for this medication");
        }

        sb.append("\n\n--- SAFETY CHECKS ---\n");
        sb.append("• Verify patient allergies\n");
        sb.append("• Check renal/hepatic function if chronic use\n");
        sb.append("• Reassess if no improvement in 48h");

        return sb.toString();
    }

    private void handleParacetamol(StringBuilder sb, double value, int age, boolean isWeightBased,
                                   double mgPerUnit, double mlPerUnit) {
        if (!isWeightBased) {
            sb.append("Paracetamol requires weight-based dosing\n");
            return;
        }

        if (age >= 0 && age <= 28) {
            sb.append("NEONATE SPECIAL DOSING:\n");
            double doseMg = Math.min(value * 10, 60);
            double doseMl = (doseMg/mgPerUnit)*mlPerUnit;
            sb.append(String.format("Dose: %s mg (%s ml) Q8H\n", df.format(doseMg), df.format(doseMl)));
            sb.append("MAX 30mg/kg/day in neonates\n");
            return;
        }

        double doseMg = Math.min(value * 15, 1000);
        double doseMl = (doseMg/mgPerUnit)*mlPerUnit;

        sb.append(String.format("Standard dose: %s mg (%s ml) Q4-6H\n", df.format(doseMg), df.format(doseMl)));
        sb.append(String.format("MAX %s mg/day (%s mg/kg/day)\n", df.format(value*75), df.format(75)));

        if (age >= 2 && value > age*2 + 9) {
            double ibw = age*2 + 9;
            sb.append(String.format("\nOBESITY ADJUSTMENT:\nIdeal BW: %s kg\n", df.format(ibw)));
            sb.append(String.format("Adjusted dose: %s mg Q4-6H\n", df.format(ibw*15)));
        }
    }

    private void handleParacetamolSuppository(StringBuilder sb, double value, int age, boolean isWeightBased) {
        if (!isWeightBased) {
            sb.append("Suppositories require weight-based dosing\n");
            return;
        }

        sb.append("RECTAL PARACETAMOL:\n");
        if (value < 5) {
            sb.append("80 mg suppository Q6H\n");
        } else if (value < 10) {
            sb.append("125 mg suppository Q6H\n");
        } else if (value < 15) {
            sb.append("250 mg suppository Q6H\n");
        } else {
            sb.append("500 mg suppository Q6H\n");
        }
        sb.append("MAX 4 doses per day\n");
    }

    private void handleDiclofenac(StringBuilder sb, double value, int age, boolean isWeightBased) {
        if (!isWeightBased) {
            sb.append("Diclofenac requires weight-based dosing\n");
            return;
        }

        sb.append("DICLOFENAC SUPPOSITORY:\n");
        if (value < 8) {
            sb.append("⚠️ Not recommended for weight <8 kg\n");
        } else if (value < 25) {
            sb.append("12.5 mg suppository Q8H\n");
            sb.append("MAX 37.5 mg/day\n");
        } else {
            sb.append("25 mg suppository Q8H\n");
            sb.append("MAX 75 mg/day\n");
        }
        sb.append("\nWARNINGS:\n");
        sb.append("• Higher CV risk than other NSAIDs\n");
        sb.append("• Monitor BP if used >2 weeks\n");
    }

    private double parseInputValue(String inputText) {
        try {
            return Double.parseDouble(inputText);
        } catch (NumberFormatException e) {
            showToast("Invalid number format");
            return 0;
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}