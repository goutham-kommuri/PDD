package com.example.myapplication;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class antihistamine extends AppCompatActivity {
    private Spinner spinnerDrug;
    private EditText etAge, etInput;
    private RadioGroup radioGroup;
    private RadioButton radioWeight, radioAge;
    private Button btnCalculate;
    private TextView tvResult;
    private final DecimalFormat df = new DecimalFormat("0.00");

    // Firebase variables
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.antihistamine);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        initializeViews();
        setupDrugSpinner();
        setupCalculateButton();
    }

    private void initializeViews() {
        spinnerDrug = findViewById(R.id.spinnerDrug);
        etAge = findViewById(R.id.etAge);
        etInput = findViewById(R.id.etInput);
        radioGroup = findViewById(R.id.radioGroup);
        radioWeight = findViewById(R.id.radioWeight);
        radioAge = findViewById(R.id.radioAge);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);
    }

    private void setupDrugSpinner() {
        String[] drugs = {
                "Select a drug", "Diphenhydramine", "Loratadine", "Cetirizine", "Fexofenadine",
                "Desloratadine", "Hydroxyzine", "Chlorpheniramine", "Brompheniramine",
                "Levocetirizine", "Promethazine", "Ebastine", "Azelastine", "Rupatadine",
                "Mizolastine", "Triprolidine", "Cyproheptadine", "Dexchlorpheniramine"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, drugs);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDrug.setAdapter(adapter);
    }

    private void setupCalculateButton() {
        btnCalculate.setOnClickListener(v -> {
            try {
                calculateDosage();
            } catch (Exception e) {
                showToast("Calculation error: " + e.getMessage());
            }
        });
    }

    private void calculateDosage() {
        String selectedDrug = spinnerDrug.getSelectedItem().toString();
        String ageText = etAge.getText().toString().trim();
        String inputText = etInput.getText().toString().trim();

        if (selectedDrug.equals("Select a drug")) {
            tvResult.setText("Please select a medication.");
            return;
        }
        if (inputText.isEmpty()) {
            showToast("Please enter weight/age");
            return;
        }

        double inputValue = parseInputValue(inputText);
        if (inputValue <= 0) {
            showToast("Value must be positive");
            return;
        }

        int age = ageText.isEmpty() ? -1 : Integer.parseInt(ageText);
        boolean isWeightBased = radioWeight.isChecked();
        String result = generateDosingRecommendation(selectedDrug, inputValue, age, isWeightBased);
        tvResult.setText(result);

        // Save to Firebase
        saveCalculationToDatabase(selectedDrug, inputValue, age, isWeightBased, result);
    }

    private void saveCalculationToDatabase(String drug, double value, int age, boolean isWeightBased, String result) {
        if (mAuth.getCurrentUser() == null) {
            showToast("Not logged in - calculation not saved");
            return;
        }

        String uid = mAuth.getCurrentUser().getUid();
        DatabaseReference userCalculationsRef = mDatabase.child("calculations")
                .child(uid)
                .child("antihistamine");

        String calculationId = userCalculationsRef.push().getKey();

        Map<String, Object> calculationData = new HashMap<>();
        calculationData.put("drug", drug);
        calculationData.put("value", value);
        calculationData.put("age", age);
        calculationData.put("isWeightBased", isWeightBased);
        calculationData.put("result", result);
        calculationData.put("timestamp", System.currentTimeMillis());

        if (calculationId != null) {
            userCalculationsRef.child(calculationId).setValue(calculationData)
                    .addOnSuccessListener(aVoid -> showToast("Calculation saved to history"))
                    .addOnFailureListener(e -> showToast("Failed to save calculation"));
        }
    }

    private String generateDosingRecommendation(String drug, double value, int age, boolean isWeightBased) {
        StringBuilder sb = new StringBuilder();

        switch (drug) {
            case "Diphenhydramine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.5) : df.format(age * 1)).append(" mg");
                sb.append("\nCaution: May cause drowsiness; avoid driving.");
                break;
            case "Loratadine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.2) : df.format(age * 5)).append(" mg");
                sb.append("\nInfo: Non-drowsy formula, taken once daily.");
                break;
            case "Cetirizine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.25) : df.format(age * 2.5)).append(" mg");
                sb.append("\nTip: Best taken in the evening to avoid drowsiness.");
                break;
            case "Fexofenadine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.3) : df.format(age * 3)).append(" mg");
                sb.append("\nCaution: Avoid fruit juices for better absorption.");
                break;
            case "Desloratadine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.15) : df.format(age * 2.5)).append(" mg");
                sb.append("\nInfo: Once daily, long-acting antihistamine.");
                break;
            case "Hydroxyzine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.6) : df.format(age * 2)).append(" mg");
                sb.append("\nInfo: Can cause sedation, also used for anxiety.");
                break;
            case "Chlorpheniramine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.35) : df.format(age * 2)).append(" mg");
                sb.append("\nCaution: Can cause drowsiness; avoid alcohol.");
                break;
            case "Brompheniramine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.4) : df.format(age * 3)).append(" mg");
                sb.append("\nTip: Used in many cold and allergy medications.");
                break;
            case "Levocetirizine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.3) : df.format(age * 5)).append(" mg");
                sb.append("\nInfo: Non-drowsy alternative to cetirizine.");
                break;
            case "Promethazine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.5) : df.format(age * 2)).append(" mg");
                sb.append("\nCaution: Strong sedative effects, avoid alcohol.");
                break;
            case "Ebastine":
                sb.append("Recommended dosage: ").append(isWeightBased ? df.format(value * 0.25) : df.format(age * 5)).append(" mg");
                sb.append("\nInfo: Non-drowsy, long-acting antihistamine.");
                break;
            default:
                sb.append("Consult a doctor for this medication.");
        }

        return sb.toString();
    }

    private double parseInputValue(String inputText) {
        try {
            return Double.parseDouble(inputText);
        } catch (NumberFormatException e) {
            showToast("Invalid number format");
            return 0;
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}