package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;

public class PainManagementActivity extends AppCompatActivity {
    private TabLayout tabLayout;
    private RecyclerView recyclerView;
    private PainMedicationAdapter adapter;
    private List<PainMedication> allMedications = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pain_management);

        getWindow().setStatusBarColor(ContextCompat.getColor(this, android.R.color.white));

        tabLayout = findViewById(R.id.tabLayout);
        recyclerView = findViewById(R.id.recyclerView);
        SearchView searchView = findViewById(R.id.searchView);

        styleSearchView(searchView);
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Setup tabs
        tabLayout.addTab(tabLayout.newTab().setText("NSAIDs"));
        tabLayout.addTab(tabLayout.newTab().setText("Opioids"));
        tabLayout.addTab(tabLayout.newTab().setText("Acetaminophen"));
        tabLayout.addTab(tabLayout.newTab().setText("Adjuvants"));
        tabLayout.addTab(tabLayout.newTab().setText("Others"));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new PainMedicationAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        loadAllMedications();
        filterMedicationsByCategory("NSAIDs");

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterMedicationsByCategory(tab.getText().toString());
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterMedications(query);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                filterMedications(newText);
                return false;
            }
        });
    }

    private void styleSearchView(SearchView searchView) {
        try {
            int searchTextId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_src_text", null, null);
            TextView searchText = searchView.findViewById(searchTextId);
            searchText.setTextColor(Color.BLACK);
            searchText.setHintTextColor(Color.GRAY);

            ImageView searchIcon = searchView.findViewById(androidx.appcompat.R.id.search_button);
            if (searchIcon != null) {
                searchIcon.setColorFilter(Color.BLACK);
            }

            ImageView closeIcon = searchView.findViewById(androidx.appcompat.R.id.search_close_btn);
            if (closeIcon != null) {
                closeIcon.setColorFilter(Color.BLACK);
            }

            int voiceIconId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_voice_btn", null, null);
            ImageView voiceIcon = searchView.findViewById(voiceIconId);
            if (voiceIcon != null) {
                voiceIcon.setColorFilter(Color.BLACK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAllMedications() {
        allMedications.clear();

        // NSAIDs
        allMedications.add(new PainMedication("Ibuprofen", "NSAID", "Oral",
                "30-60 min", "4-6 hours", "200-800 mg every 4-6 hours",
                "Take with food to reduce GI upset", "NSAIDs",
                "Inhibits COX-1 and COX-2 enzymes, reducing prostaglandin synthesis",
                "GI irritation, bleeding risk, renal impairment, HTN exacerbation"));

        allMedications.add(new PainMedication("Naproxen", "NSAID", "Oral",
                "1-2 hours", "8-12 hours", "250-500 mg every 12 hours",
                "Longer duration than other NSAIDs", "NSAIDs",
                "Non-selective COX inhibitor with longer half-life",
                "Similar to ibuprofen but longer duration effects"));

        allMedications.add(new PainMedication("Celecoxib", "COX-2 Inhibitor", "Oral",
                "1-2 hours", "12 hours", "100-200 mg every 12-24 hours",
                "Lower GI risk than traditional NSAIDs", "NSAIDs",
                "Selective COX-2 inhibition with less GI effects",
                "Lower GI risk but CV risks similar to other NSAIDs"));

        // Opioids
        allMedications.add(new PainMedication("Morphine", "Opioid", "IV/PO/IM",
                "IV: 5-10 min, PO: 30 min", "3-7 hours", "Varies by route (e.g., 5-10 mg IV q4h)",
                "Gold standard for severe pain", "Opioids",
                "Mu-opioid receptor agonist",
                "Respiratory depression, sedation, constipation, nausea"));

        allMedications.add(new PainMedication("Oxycodone", "Opioid", "Oral",
                "10-30 min", "4-6 hours", "5-10 mg every 4-6 hours",
                "Often combined with acetaminophen", "Opioids",
                "Mu-opioid receptor agonist with good oral bioavailability",
                "Similar to morphine but less histamine release"));

        allMedications.add(new PainMedication("Fentanyl", "Opioid", "IV/Transdermal",
                "IV: immediate, Patch: 12-24h", "IV: 30-60 min, Patch: 72h",
                "Varies (e.g., 25-100 mcg/hr patch)",
                "High potency, risk of respiratory depression", "Opioids",
                "Highly potent mu-opioid agonist",
                "Respiratory depression, chest wall rigidity with rapid IV"));

        // Acetaminophen
        allMedications.add(new PainMedication("Acetaminophen", "Analgesic/Antipyretic", "Oral/IV/PR",
                "30-60 min", "4-6 hours", "325-1000 mg every 4-6 hours (max 4g/day)",
                "Safer than NSAIDs for GI and renal issues", "Acetaminophen",
                "Central COX inhibition with minimal peripheral effect",
                "Hepatotoxicity at high doses, few other side effects"));

        // Adjuvants
        allMedications.add(new PainMedication("Gabapentin", "Anticonvulsant", "Oral",
                "2-3 hours", "5-7 hours", "100-600 mg TID (up to 3600 mg/day)",
                "Useful for neuropathic pain", "Adjuvants",
                "Binds α2δ subunit of voltage-gated calcium channels",
                "Dizziness, sedation, peripheral edema"));

        allMedications.add(new PainMedication("Amitriptyline", "TCA", "Oral",
                "2-4 weeks for full effect", "NA", "10-75 mg at bedtime",
                "Low doses often effective for pain", "Adjuvants",
                "Inhibits serotonin/norepinephrine reuptake",
                "Anticholinergic effects, sedation, cardiac arrhythmias"));

        // Others
        allMedications.add(new PainMedication("Lidocaine", "Local Anesthetic", "Topical/IV",
                "Topical: 30-60 min, IV: immediate", "1-2 hours", "Varies by formulation",
                "Patch useful for post-herpetic neuralgia", "Others",
                "Sodium channel blockade",
                "Cardiac arrhythmias at high systemic doses"));

        allMedications.add(new PainMedication("Ketamine", "NMDA Antagonist", "IV/IM/PO",
                "IV: immediate, PO: 20-30 min", "IV: 30-60 min, PO: 2-4 hours",
                "Low dose: 0.1-0.5 mg/kg IV", "Useful for refractory pain", "Others",
                "NMDA receptor antagonism reducing central sensitization",
                "Psychomimetic effects, hypertension, emergence reactions"));
    }

    private void filterMedicationsByCategory(String category) {
        List<PainMedication> filtered = new ArrayList<>();
        for (PainMedication medication : allMedications) {
            if (medication.getCategory().equals(category)) {
                filtered.add(medication);
            }
        }
        adapter.updateList(filtered);
    }

    private void filterMedications(String query) {
        String currentTab = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getText().toString();
        List<PainMedication> filtered = new ArrayList<>();

        for (PainMedication medication : allMedications) {
            if (medication.getCategory().equals(currentTab) &&
                    medication.getName().toLowerCase().contains(query.toLowerCase())) {
                filtered.add(medication);
            }
        }
        adapter.updateList(filtered);
    }
}