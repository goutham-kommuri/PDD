// AnticoagulationActivity.java
package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;

public class AnticoagulationActivity extends AppCompatActivity {
    private TabLayout tabLayout;
    private RecyclerView recyclerView;
    private AnticoagulantAdapter adapter;
    private List<Anticoagulant> allAnticoagulants = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anticoagulation);

        // Set status bar color
        getWindow().setStatusBarColor(ContextCompat.getColor(this, android.R.color.white));

        tabLayout = findViewById(R.id.tabLayout);
        recyclerView = findViewById(R.id.recyclerView);
        SearchView searchView = findViewById(R.id.searchView);

        // Style the SearchView
        styleSearchView(searchView);
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Setup tabs
        tabLayout.addTab(tabLayout.newTab().setText("Warfarin"));
        tabLayout.addTab(tabLayout.newTab().setText("DOACs"));
        tabLayout.addTab(tabLayout.newTab().setText("Heparins"));
        tabLayout.addTab(tabLayout.newTab().setText("Parenteral"));
        tabLayout.addTab(tabLayout.newTab().setText("Reversal Agents"));

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AnticoagulantAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // Load all anticoagulants
        loadAllAnticoagulants();

        // Default to Warfarin tab
        filterAnticoagulantsByCategory("Warfarin");

        // Tab selection listener
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterAnticoagulantsByCategory(tab.getText().toString());
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        // Search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterAnticoagulants(query);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                filterAnticoagulants(newText);
                return false;
            }
        });
    }

    private void styleSearchView(SearchView searchView) {
        try {
            // Set text color
            int searchTextId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_src_text", null, null);
            TextView searchText = searchView.findViewById(searchTextId);
            searchText.setTextColor(Color.BLACK);
            searchText.setHintTextColor(Color.GRAY);

            // Set search icon color
            ImageView searchIcon = searchView.findViewById(androidx.appcompat.R.id.search_button);
            if (searchIcon != null) {
                searchIcon.setColorFilter(Color.BLACK);
            }

            // Set close icon color
            ImageView closeIcon = searchView.findViewById(androidx.appcompat.R.id.search_close_btn);
            if (closeIcon != null) {
                closeIcon.setColorFilter(Color.BLACK);
            }

            // Set voice icon color if exists
            int voiceIconId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_voice_btn", null, null);
            ImageView voiceIcon = searchView.findViewById(voiceIconId);
            if (voiceIcon != null) {
                voiceIcon.setColorFilter(Color.BLACK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAllAnticoagulants() {
        allAnticoagulants.clear();

        // Warfarin
        allAnticoagulants.add(new Anticoagulant("Warfarin", "Vitamin K antagonist", "Oral",
                "36-72 hours", "20-60 hours", "Vitamin K, PCC, FFP",
                "INR (target 2-3 usually)", "Many drug/food interactions, requires regular monitoring", "Warfarin"));

        // DOACs (Direct Oral Anticoagulants)
        allAnticoagulants.add(new Anticoagulant("Dabigatran", "Direct thrombin inhibitor", "Oral",
                "1-2 hours", "12-17 hours", "Idarucizumab",
                "aPTT, TT (not routine)", "Reduce dose in renal impairment", "DOACs"));

        allAnticoagulants.add(new Anticoagulant("Rivaroxaban", "Factor Xa inhibitor", "Oral",
                "2-4 hours", "5-13 hours", "Andexanet alfa, PCC",
                "Anti-Xa level (not routine)", "Once daily dosing, take with food", "DOACs"));

        allAnticoagulants.add(new Anticoagulant("Apixaban", "Factor Xa inhibitor", "Oral",
                "3-4 hours", "8-15 hours", "Andexanet alfa, PCC",
                "Anti-Xa level (not routine)", "Twice daily dosing, lower bleeding risk", "DOACs"));

        allAnticoagulants.add(new Anticoagulant("Edoxaban", "Factor Xa inhibitor", "Oral",
                "1-2 hours", "10-14 hours", "Andexanet alfa, PCC",
                "Anti-Xa level (not routine)", "Once daily dosing, reduce dose with high CrCl", "DOACs"));

        // Heparins
        allAnticoagulants.add(new Anticoagulant("Unfractionated Heparin", "Heparin", "IV/SC",
                "Immediate (IV)", "1-2 hours", "Protamine sulfate",
                "aPTT (target 1.5-2.5x control)", "Risk of HIT, requires monitoring", "Heparins"));

        allAnticoagulants.add(new Anticoagulant("Enoxaparin", "LMWH", "SC",
                "3-5 hours", "4-5 hours", "Protamine sulfate (partial)",
                "Anti-Xa level (if needed)", "Dose adjustment in renal impairment", "Heparins"));

        allAnticoagulants.add(new Anticoagulant("Dalteparin", "LMWH", "SC",
                "3-5 hours", "3-5 hours", "Protamine sulfate (partial)",
                "Anti-Xa level (if needed)", "Cancer-associated VTE treatment", "Heparins"));

        allAnticoagulants.add(new Anticoagulant("Fondaparinux", "Factor Xa inhibitor", "SC",
                "2-4 hours", "17-21 hours", "None specific",
                "Anti-Xa level (if needed)", "Contraindicated in CrCl <30", "Heparins"));

        // Parenteral
        allAnticoagulants.add(new Anticoagulant("Argatroban", "Direct thrombin inhibitor", "IV",
                "Immediate", "39-51 minutes", "None specific",
                "aPTT", "HIT treatment, hepatically metabolized", "Parenteral"));

        allAnticoagulants.add(new Anticoagulant("Bivalirudin", "Direct thrombin inhibitor", "IV",
                "Immediate", "25 minutes", "None specific",
                "aPTT, ACT", "PCI anticoagulation, short half-life", "Parenteral"));

        // Reversal Agents
        allAnticoagulants.add(new Anticoagulant("Vitamin K", "Vitamin K", "Oral/IV",
                "6-12 hours (oral)", "N/A", "N/A",
                "INR", "Slow reversal, takes hours to days", "Reversal Agents"));

        allAnticoagulants.add(new Anticoagulant("Protamine sulfate", "Heparin antagonist", "IV",
                "Immediate", "N/A", "N/A",
                "aPTT", "Risk of hypotension, anaphylaxis", "Reversal Agents"));

        allAnticoagulants.add(new Anticoagulant("Idarucizumab", "Dabigatran reversal", "IV",
                "Immediate", "N/A", "N/A",
                "TT, aPTT", "Specific for dabigatran", "Reversal Agents"));

        allAnticoagulants.add(new Anticoagulant("Andexanet alfa", "Factor Xa reversal", "IV",
                "Immediate", "N/A", "N/A",
                "Anti-Xa level", "For rivaroxaban, apixaban, edoxaban", "Reversal Agents"));

        allAnticoagulants.add(new Anticoagulant("PCC", "Prothrombin complex", "IV",
                "Immediate", "N/A", "N/A",
                "INR", "Contains factors II, VII, IX, X", "Reversal Agents"));
    }

    private void filterAnticoagulantsByCategory(String category) {
        List<Anticoagulant> filtered = new ArrayList<>();
        for (Anticoagulant anticoagulant : allAnticoagulants) {
            if (anticoagulant.getCategory().equals(category)) {
                filtered.add(anticoagulant);
            }
        }
        adapter.updateList(filtered);
    }

    private void filterAnticoagulants(String query) {
        String currentTab = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getText().toString();
        List<Anticoagulant> filtered = new ArrayList<>();

        for (Anticoagulant anticoagulant : allAnticoagulants) {
            if (anticoagulant.getCategory().equals(currentTab) &&
                    anticoagulant.getName().toLowerCase().contains(query.toLowerCase())) {
                filtered.add(anticoagulant);
            }
        }
        adapter.updateList(filtered);
    }
}