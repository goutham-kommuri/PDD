// IVFluidAdapter.java
package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class IVFluidAdapter extends RecyclerView.Adapter<IVFluidAdapter.ViewHolder> {
    private List<IVFluid> ivFluidList;

    public IVFluidAdapter(List<IVFluid> ivFluidList) {
        this.ivFluidList = ivFluidList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_ivfluid_table, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        IVFluid ivFluid = ivFluidList.get(position);

        holder.fluidName.setText(ivFluid.getName());
        holder.fluidType.setText(ivFluid.getType());
        holder.fluidComposition.setText("Composition: " + ivFluid.getComposition());
        holder.fluidOsmolarity.setText("Osmolarity: " + ivFluid.getOsmolarity());
        holder.fluidPH.setText("pH: " + ivFluid.getpH());
        holder.fluidIndications.setText("Indications: " + ivFluid.getIndications());
        holder.fluidContraindications.setText("Contraindications: " + ivFluid.getContraindications());
        holder.fluidConsiderations.setText("Considerations: " + ivFluid.getConsiderations());
    }

    @Override
    public int getItemCount() {
        return ivFluidList.size();
    }

    public void updateList(List<IVFluid> newList) {
        ivFluidList = newList;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView fluidName, fluidType, fluidComposition, fluidOsmolarity,
                fluidPH, fluidIndications, fluidContraindications, fluidConsiderations;

        ViewHolder(View itemView) {
            super(itemView);
            fluidName = itemView.findViewById(R.id.fluidName);
            fluidType = itemView.findViewById(R.id.fluidType);
            fluidComposition = itemView.findViewById(R.id.fluidComposition);
            fluidOsmolarity = itemView.findViewById(R.id.fluidOsmolarity);
            fluidPH = itemView.findViewById(R.id.fluidPH);
            fluidIndications = itemView.findViewById(R.id.fluidIndications);
            fluidContraindications = itemView.findViewById(R.id.fluidContraindications);
            fluidConsiderations = itemView.findViewById(R.id.fluidConsiderations);
        }
    }
}