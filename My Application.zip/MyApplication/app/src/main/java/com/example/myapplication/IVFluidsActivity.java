// IVFluidsActivity.java
package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;

public class IVFluidsActivity extends AppCompatActivity {
    private TabLayout tabLayout;
    private RecyclerView recyclerView;
    private IVFluidAdapter adapter;
    private List<IVFluid> allIVFluids = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ivfluids);

        getWindow().setStatusBarColor(ContextCompat.getColor(this, android.R.color.white));

        tabLayout = findViewById(R.id.tabLayout);
        recyclerView = findViewById(R.id.recyclerView);
        SearchView searchView = findViewById(R.id.searchView);

        styleSearchView(searchView);
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());

        // Setup tabs
        tabLayout.addTab(tabLayout.newTab().setText("Crystalloids"));
        tabLayout.addTab(tabLayout.newTab().setText("Colloids"));
        tabLayout.addTab(tabLayout.newTab().setText("Electrolytes"));
        tabLayout.addTab(tabLayout.newTab().setText("Special Solutions"));
        tabLayout.addTab(tabLayout.newTab().setText("Nutritional"));

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new IVFluidAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // Load all IV fluids
        loadAllIVFluids();

        // Default to Crystalloids tab
        filterIVFluidsByCategory("Crystalloids");

        // Tab selection listener
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterIVFluidsByCategory(tab.getText().toString());
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        // Search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterIVFluids(query);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                filterIVFluids(newText);
                return false;
            }
        });
    }

    private void styleSearchView(SearchView searchView) {
        try {
            int searchTextId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_src_text", null, null);
            TextView searchText = searchView.findViewById(searchTextId);
            searchText.setTextColor(Color.BLACK);
            searchText.setHintTextColor(Color.GRAY);

            ImageView searchIcon = searchView.findViewById(androidx.appcompat.R.id.search_button);
            if (searchIcon != null) {
                searchIcon.setColorFilter(Color.BLACK);
            }

            ImageView closeIcon = searchView.findViewById(androidx.appcompat.R.id.search_close_btn);
            if (closeIcon != null) {
                closeIcon.setColorFilter(Color.BLACK);
            }

            int voiceIconId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_voice_btn", null, null);
            ImageView voiceIcon = searchView.findViewById(voiceIconId);
            if (voiceIcon != null) {
                voiceIcon.setColorFilter(Color.BLACK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAllIVFluids() {
        allIVFluids.clear();

        // Crystalloids
        allIVFluids.add(new IVFluid("Normal Saline (0.9% NaCl)", "Isotonic Crystalloid",
                "Na+ 154 mEq/L, Cl- 154 mEq/L", "308 mOsm/L", "4.5-7.0",
                "Fluid resuscitation, maintenance fluids, diluent for medications",
                "Volume overload, hypernatremia, metabolic alkalosis",
                "Can cause hyperchloremic metabolic acidosis with large volumes", "Crystalloids"));

        allIVFluids.add(new IVFluid("Lactated Ringer's", "Balanced Crystalloid",
                "Na+ 130 mEq/L, Cl- 109 mEq/L, K+ 4 mEq/L, Ca++ 3 mEq/L, Lactate 28 mEq/L",
                "273 mOsm/L", "6.5",
                "Fluid resuscitation, surgery, trauma, burns",
                "Liver failure, severe metabolic acidosis, hypercalcemia",
                "Contains lactate (metabolized to bicarbonate), preferred in most cases over NS", "Crystalloids"));

        allIVFluids.add(new IVFluid("D5W", "Hypotonic Crystalloid",
                "Dextrose 50 g/L (278 mOsm/L)", "252 mOsm/L", "4.0",
                "Free water replacement, hypernatremia, insulin-induced hypoglycemia",
                "Post-neurosurgery, increased ICP risk, SIADH",
                "Becomes hypotonic once dextrose is metabolized", "Crystalloids"));

        // Colloids
        allIVFluids.add(new IVFluid("Albumin 5%", "Natural Colloid",
                "Albumin 50 g/L, Na+ 130-160 mEq/L", "290 mOsm/L", "6.4-7.4",
                "Severe hypoalbuminemia, large volume paracentesis, burns",
                "Allergy to albumin, severe anemia, HF with normal plasma volume",
                "Expensive, risk of disease transmission (very low)", "Colloids"));

        allIVFluids.add(new IVFluid("Hetastarch 6%", "Synthetic Colloid",
                "Hydroxyethyl starch in NS", "310 mOsm/L", "5.5",
                "Volume expansion in acute hypovolemia (controversial)",
                "Renal impairment, severe liver disease, bleeding disorders",
                "Risk of AKI, coagulopathy - use restricted in many centers", "Colloids"));

        // Electrolytes
        allIVFluids.add(new IVFluid("3% NaCl", "Hypertonic Saline",
                "Na+ 513 mEq/L, Cl- 513 mEq/L", "1026 mOsm/L", "4.5-7.0",
                "Severe hyponatremia, cerebral edema, increased ICP",
                "Hypernatremia, volume overload",
                "Must be given via central line, monitor Na+ closely", "Electrolytes"));

        allIVFluids.add(new IVFluid("Potassium Chloride", "Electrolyte Additive",
                "K+ concentration varies (10-40 mEq/L typically)", "Varies", "4.0-8.0",
                "Hypokalemia, diabetic ketoacidosis",
                "Hyperkalemia, renal failure, severe tissue damage",
                "Never give IV push - must be diluted and infused slowly", "Electrolytes"));

        // Special Solutions
        allIVFluids.add(new IVFluid("D5 0.45% NaCl", "Maintenance Fluid",
                "Dextrose 50 g/L, Na+ 77 mEq/L, Cl- 77 mOsm/L", "406 mOsm/L", "4.0",
                "Maintenance fluids when NPO, pediatric maintenance",
                "Hyperglycemia, increased ICP",
                "Common maintenance fluid in adults and children", "Special Solutions"));

        allIVFluids.add(new IVFluid("Plasmalyte", "Balanced Crystalloid",
                "Na+ 140 mEq/L, Cl- 98 mEq/L, K+ 5 mEq/L, Mg++ 3 mEq/L, Acetate 27 mEq/L, Gluconate 23 mEq/L",
                "294 mOsm/L", "7.4",
                "Fluid resuscitation, perioperative use, liver transplantation",
                "Severe metabolic alkalosis",
                "pH balanced, less likely to cause metabolic acidosis than NS", "Special Solutions"));

        // Nutritional
        allIVFluids.add(new IVFluid("TPN", "Total Parenteral Nutrition",
                "Customized - contains dextrose, amino acids, lipids, electrolytes, vitamins, trace elements",
                "Variable (often >1000 mOsm/L)", "5.0-6.0",
                "Patients who cannot tolerate enteral nutrition >7 days",
                "Short-term use (<7 days), hyperglycemia, severe electrolyte disturbances",
                "Must be given via central line, requires strict monitoring", "Nutritional"));

        allIVFluids.add(new IVFluid("Lipid Emulsion 20%", "IV Fat Emulsion",
                "Soybean oil 200 g/L, egg phospholipids 12 g/L, glycerin 22.5 g/L",
                "260 mOsm/L", "6.0-9.0",
                "Essential fatty acid deficiency, part of TPN, local anesthetic toxicity",
                "Egg or soybean allergy, severe hyperlipidemia",
                "Provides 2 kcal/mL, can cause fat overload syndrome", "Nutritional"));
    }

    private void filterIVFluidsByCategory(String category) {
        List<IVFluid> filtered = new ArrayList<>();
        for (IVFluid fluid : allIVFluids) {
            if (fluid.getCategory().equals(category)) {
                filtered.add(fluid);
            }
        }
        adapter.updateList(filtered);
    }

    private void filterIVFluids(String query) {
        String currentTab = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getText().toString();
        List<IVFluid> filtered = new ArrayList<>();

        for (IVFluid fluid : allIVFluids) {
            if (fluid.getCategory().equals(currentTab) &&
                    fluid.getName().toLowerCase().contains(query.toLowerCase())) {
                filtered.add(fluid);
            }
        }
        adapter.updateList(filtered);
    }
}