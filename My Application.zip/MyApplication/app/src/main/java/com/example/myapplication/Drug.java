package com.example.myapplication;

public class Drug {
    private String name;
    private String type;
    private String route;
    private String onset;
    private String duration;
    private String dosage;
    private String considerations;
    private String category;

    public Drug(String name, String type, String route, String onset, String duration,
                String dosage, String considerations, String category) {
        this.name = name;
        this.type = type;
        this.route = route;
        this.onset = onset;
        this.duration = duration;
        this.dosage = dosage;
        this.considerations = considerations;
        this.category = category;
    }

    // Getters
    public String getName() { return name; }
    public String getType() { return type; }
    public String getRoute() { return route; }
    public String getOnset() { return onset; }
    public String getDuration() { return duration; }
    public String getDosage() { return dosage; }
    public String getConsiderations() { return considerations; }
    public String getCategory() { return category; }
}