// IVFluid.java
package com.example.myapplication;

public class IVFluid {
    private String name;
    private String type;
    private String composition;
    private String osmolarity;
    private String pH;
    private String indications;
    private String contraindications;
    private String considerations;
    private String category;

    public IVFluid(String name, String type, String composition, String osmolarity,
                   String pH, String indications, String contraindications,
                   String considerations, String category) {
        this.name = name;
        this.type = type;
        this.composition = composition;
        this.osmolarity = osmolarity;
        this.pH = pH;
        this.indications = indications;
        this.contraindications = contraindications;
        this.considerations = considerations;
        this.category = category;
    }

    // Getters
    public String getName() { return name; }
    public String getType() { return type; }
    public String getComposition() { return composition; }
    public String getOsmolarity() { return osmolarity; }
    public String getpH() { return pH; }
    public String getIndications() { return indications; }
    public String getContraindications() { return contraindications; }
    public String getConsiderations() { return considerations; }
    public String getCategory() { return category; }
}