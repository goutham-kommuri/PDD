// Anticoagulant.java
package com.example.myapplication;

public class Anticoagulant {
    private String name;
    private String drugClass;
    private String route;
    private String onset;
    private String halfLife;
    private String reversalAgent;
    private String monitoring;
    private String considerations;
    private String category;

    public Anticoagulant(String name, String drugClass, String route, String onset,
                         String halfLife, String reversalAgent, String monitoring,
                         String considerations, String category) {
        this.name = name;
        this.drugClass = drugClass;
        this.route = route;
        this.onset = onset;
        this.halfLife = halfLife;
        this.reversalAgent = reversalAgent;
        this.monitoring = monitoring;
        this.considerations = considerations;
        this.category = category;
    }

    // Getters
    public String getName() { return name; }
    public String getDrugClass() { return drugClass; }
    public String getRoute() { return route; }
    public String getOnset() { return onset; }
    public String getHalfLife() { return halfLife; }
    public String getReversalAgent() { return reversalAgent; }
    public String getMonitoring() { return monitoring; }
    public String getConsiderations() { return considerations; }
    public String getCategory() { return category; }
}