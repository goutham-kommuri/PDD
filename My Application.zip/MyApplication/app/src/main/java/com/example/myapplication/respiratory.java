package com.example.myapplication;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class respiratory extends AppCompatActivity {
    private Spinner spinnerDrug;
    private EditText etAge, etInput;
    private RadioButton radioWeight, radioAge;
    private Button btnCalculate;
    private TextView tvResult;
    private final DecimalFormat df = new DecimalFormat("0.00");

    // Firebase variables
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.respiratory);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Initialize UI Components
        spinnerDrug = findViewById(R.id.spinnerDrug);
        etAge = findViewById(R.id.etAge);
        etInput = findViewById(R.id.etInput);
        radioWeight = findViewById(R.id.radioWeight);
        radioAge = findViewById(R.id.radioAge);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);

        // Populate Medication Spinner
        String[] medications = {"Salbutamol", "Budesonide", "Montelukast", "Ipratropium", "Theophylline"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, medications);
        spinnerDrug.setAdapter(adapter);

        // Calculate Button Click Listener
        btnCalculate.setOnClickListener(v -> {
            try {
                calculateDosage();
            } catch (Exception e) {
                tvResult.setText("Error: " + e.getMessage());
            }
        });
    }

    private void calculateDosage() {
        String selectedDrug = spinnerDrug.getSelectedItem().toString();
        String ageStr = etAge.getText().toString();
        String inputStr = etInput.getText().toString();

        if (ageStr.isEmpty() || inputStr.isEmpty()) {
            tvResult.setText("Please enter age and weight/age value.");
            return;
        }

        int ageMonths = Integer.parseInt(ageStr);
        double value = Double.parseDouble(inputStr);
        boolean isWeightBased = radioWeight.isChecked();

        String result = generateDosingRecommendation(selectedDrug, ageMonths, value, isWeightBased);
        tvResult.setText(result);

        // Save to Firebase
        saveCalculationToDatabase(selectedDrug, ageMonths, value, isWeightBased, result);
    }

    private String generateDosingRecommendation(String drug, int ageMonths, double value, boolean isWeightBased) {
        double dosage = 0;
        String unit = "mg";
        StringBuilder recommendation = new StringBuilder();

        switch (drug) {
            case "Salbutamol":
                dosage = isWeightBased ? value * 0.15 : ageMonths * 0.02;
                recommendation.append("Salbutamol Dosage: ").append(df.format(dosage)).append(" mg per dose\n");
                recommendation.append("Max 4 doses/day, space doses 4-6 hours apart");
                break;
            case "Budesonide":
                dosage = isWeightBased ? value * 0.5 : ageMonths * 0.05;
                unit = "mcg";
                recommendation.append("Budesonide Dosage: ").append(df.format(dosage)).append(" mcg per dose\n");
                recommendation.append("Administer via nebulizer or inhaler with spacer");
                break;
            case "Montelukast":
                dosage = ageMonths >= 24 ? 4 : (ageMonths >= 6 ? 2 : 1);
                recommendation.append("Montelukast Dosage: ").append(df.format(dosage)).append(" mg once daily\n");
                recommendation.append("Take in the evening for asthma control");
                break;
            case "Ipratropium":
                dosage = isWeightBased ? value * 0.01 : ageMonths * 0.005;
                unit = "mcg";
                recommendation.append("Ipratropium Dosage: ").append(df.format(dosage)).append(" mcg per dose\n");
                recommendation.append("Combine with beta-agonist for acute bronchospasm");
                break;
            case "Theophylline":
                dosage = isWeightBased ? value * 1.0 : ageMonths * 0.2;
                recommendation.append("Theophylline Dosage: ").append(df.format(dosage)).append(" mg per dose\n");
                recommendation.append("Monitor serum levels (target 5-15 mcg/mL)");
                break;
            default:
                return "Please select a valid medication.";
        }

        // Add general warnings
        recommendation.append("\n\n--- SAFETY NOTES ---\n");
        recommendation.append("• Verify patient allergies\n");
        recommendation.append("• Adjust for renal/hepatic impairment if needed\n");
        recommendation.append("• Monitor for adverse effects");

        return recommendation.toString();
    }

    private void saveCalculationToDatabase(String drug, int ageMonths, double value, boolean isWeightBased, String result) {
        if (mAuth.getCurrentUser() == null) {
            Toast.makeText(this, "Not logged in - calculation not saved", Toast.LENGTH_SHORT).show();
            return;
        }

        String uid = mAuth.getCurrentUser().getUid();
        DatabaseReference userCalculationsRef = mDatabase.child("calculations")
                .child(uid)
                .child("respiratory");

        String calculationId = userCalculationsRef.push().getKey();

        Map<String, Object> calculationData = new HashMap<>();
        calculationData.put("drug", drug);
        calculationData.put("ageMonths", ageMonths);
        calculationData.put("value", value);
        calculationData.put("isWeightBased", isWeightBased);
        calculationData.put("result", result);
        calculationData.put("timestamp", System.currentTimeMillis());

        if (calculationId != null) {
            userCalculationsRef.child(calculationId).setValue(calculationData)
                    .addOnSuccessListener(aVoid -> Toast.makeText(respiratory.this, "Calculation saved", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e -> Toast.makeText(respiratory.this, "Save failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
        }
    }
}