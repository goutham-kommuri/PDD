package com.example.myapplication;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.components.Legend;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public class BMICalculatorActivity extends AppCompatActivity {

    // UI Elements
    private EditText nameInput, weightInput, heightInput, ageInput;
    private ToggleButton maleButton, femaleButton;
    private SwitchCompat weightSwitch, heightSwitch;

    // Firebase
    private DatabaseReference databaseReference;
    private FirebaseUser currentUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_calculator);
        initializeViews();
        setupFirebase();
        setupGenderButtons();
    }

    private void initializeViews() {
        nameInput = findViewById(R.id.name_input);
        weightInput = findViewById(R.id.weight_input);
        heightInput = findViewById(R.id.height_input);
        ageInput = findViewById(R.id.age_input);
        maleButton = findViewById(R.id.male_button);
        femaleButton = findViewById(R.id.female_button);
        weightSwitch = findViewById(R.id.weight_toggle);
        heightSwitch = findViewById(R.id.height_toggle);

        ImageButton backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(view -> onBackPressed());

        Button submitButton = findViewById(R.id.submit_button);
        submitButton.setOnClickListener(view -> calculateBMIAndLBM());
    }

    private void setupFirebase() {
        currentUser = FirebaseAuth.getInstance().getCurrentUser();
        databaseReference = FirebaseDatabase.getInstance().getReference("calculations");
    }

    private void setupGenderButtons() {
        maleButton.setOnClickListener(view -> {
            maleButton.setChecked(true);
            femaleButton.setChecked(false);
            updateGenderButtonStyles();
        });

        femaleButton.setOnClickListener(view -> {
            femaleButton.setChecked(true);
            maleButton.setChecked(false);
            updateGenderButtonStyles();
        });
    }

    private void updateGenderButtonStyles() {
        maleButton.setBackgroundResource(
                maleButton.isChecked() ? R.drawable.button_selected : R.drawable.button_unselected);
        femaleButton.setBackgroundResource(
                femaleButton.isChecked() ? R.drawable.button_selected : R.drawable.button_unselected);
    }

    private void calculateBMIAndLBM() {
        if (!validateInputs()) return;

        try {
            String name = nameInput.getText().toString().trim();
            int age = Integer.parseInt(ageInput.getText().toString().trim());
            double weight = parseWeight(weightInput.getText().toString().trim());
            double height = parseHeight(heightInput.getText().toString().trim());
            boolean isMale = maleButton.isChecked();

            double bmi = calculateBMI(weight, height);
            double lbm = calculateLBM(weight, height, isMale);
            String category = getBMICategory(bmi);

            showResultsDialog(name, age, bmi, lbm, category, isMale);
            saveBmiRecord(name, age, bmi, lbm, category, weight, height, isMale);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input format", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean validateInputs() {
        if (nameInput.getText().toString().trim().isEmpty() ||
                weightInput.getText().toString().trim().isEmpty() ||
                heightInput.getText().toString().trim().isEmpty() ||
                ageInput.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Please enter all values", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private double parseWeight(String weightStr) {
        double weight = Double.parseDouble(weightStr);
        return weightSwitch.isChecked() ? weight : weight * 0.453592; // lbs to kg
    }

    private double parseHeight(String heightStr) {
        if (heightSwitch.isChecked()) {
            return Double.parseDouble(heightStr); // cm
        } else {
            String[] parts = heightStr.split("-");
            if (parts.length != 2) {
                Toast.makeText(this, "Enter height as ft-in (e.g., 5-9)", Toast.LENGTH_SHORT).show();
                throw new NumberFormatException("Invalid height format");
            }
            double feet = Double.parseDouble(parts[0]);
            double inches = Double.parseDouble(parts[1]);
            return (feet * 30.48) + (inches * 2.54); // ft+in to cm
        }
    }

    private double calculateBMI(double weightKg, double heightCm) {
        double heightMeters = heightCm / 100;
        return weightKg / (heightMeters * heightMeters);
    }

    private double calculateLBM(double weightKg, double heightCm, boolean isMale) {
        // Boer formula for LBM calculation
        if (isMale) {
            return (0.407 * weightKg) + (0.267 * heightCm) - 19.2;
        } else {
            return (0.252 * weightKg) + (0.473 * heightCm) - 48.3;
        }
    }

    private String getBMICategory(double bmi) {
        if (bmi < 18.5) return "Underweight";
        if (bmi < 25) return "Normal";
        if (bmi < 30) return "Overweight";
        return "Obese";
    }

    private void showResultsDialog(String name, int age, double bmi, double lbm,
                                   String category, boolean isMale) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AlertDialogTheme);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_bmi_results, null);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        dialog.show();

        // Initialize views
        TextView bmiResult = dialogView.findViewById(R.id.popup_bmi_result);
        TextView bmiCategory = dialogView.findViewById(R.id.popup_bmi_category);
        TextView lbmResult = dialogView.findViewById(R.id.popup_lbm_result);
        TextView recommendations = dialogView.findViewById(R.id.popup_recommendations);
        PieChart bmiChart = dialogView.findViewById(R.id.popup_pie_chart);
        PieChart lbmChart = dialogView.findViewById(R.id.popup_lbm_chart);
        Button closeButton = dialogView.findViewById(R.id.btn_close);

        // Set results
        bmiResult.setText(String.format("BMI: %.1f", bmi));
        bmiCategory.setText(String.format("Category: %s", category));
        lbmResult.setText(String.format("LBM: %.1f kg", lbm));
        recommendations.setText(getClinicalRecommendations(bmi, lbm, category, isMale, age));

        // Setup charts
        setupBMIPieChart(bmiChart, bmi, category);
        setupLBMPieChart(lbmChart, lbm, isMale, age);

        closeButton.setOnClickListener(v -> dialog.dismiss());
    }

    private String getClinicalRecommendations(double bmi, double lbm, String category,
                                              boolean isMale, int age) {
        StringBuilder sb = new StringBuilder();
        sb.append("Clinical Assessment:\n\n");

        // BMI-based recommendations
        switch (category) {
            case "Underweight":
                sb.append("• Evaluate for malnutrition/eating disorders\n");
                sb.append("• Consider DEXA scan for bone density\n");
                sb.append("• Nutritional rehabilitation program\n");
                break;
            case "Normal":
                sb.append("• Maintain healthy lifestyle\n");
                sb.append("• Annual metabolic screening\n");
                break;
            case "Overweight":
                sb.append("• Screen for metabolic syndrome\n");
                sb.append("• 5-10% weight loss target\n");
                sb.append("• Lifestyle modification program\n");
                break;
            case "Obese":
                sb.append("• Comprehensive metabolic workup\n");
                sb.append("• Consider bariatric referral if BMI ≥ 40\n");
                sb.append("• Multidisciplinary approach recommended\n");
                break;
        }

        // LBM-based recommendations
        double idealLBM = calculateIdealLBM(isMale, age);
        double lbmDifference = lbm - idealLBM;

        sb.append("\nLBM Analysis:\n");
        if (lbmDifference < -3) {
            sb.append("• Significant LBM deficit (possible sarcopenia)\n");
            sb.append("• Resistance training program\n");
            sb.append("• Protein supplementation\n");
        } else if (lbmDifference < 0) {
            sb.append("• Mild LBM deficit\n");
            sb.append("• Consider strength training\n");
        } else if (lbmDifference > 5) {
            sb.append("• Elevated LBM (hypertrophy)\n");
            if (!isMale) {
                sb.append("• Evaluate for hormonal imbalances\n");
            }
        } else {
            sb.append("• LBM within normal range\n");
        }

        sb.append("\nMonitoring Plan:\n");
        sb.append("• Reassess in 3 months\n");
        sb.append("• Track waist circumference changes\n");
        sb.append("• Consider body composition analysis\n");

        return sb.toString();
    }

    private double calculateIdealLBM(boolean isMale, int age) {
        // Simplified clinical estimation
        if (isMale) {
            return age < 50 ? 75 : 70; // kg
        } else {
            return age < 50 ? 55 : 50; // kg
        }
    }

    private void setupBMIPieChart(PieChart chart, double bmi, String category) {
        ArrayList<PieEntry> entries = new ArrayList<>();

        // Calculate segments based on BMI position
        if (bmi < 18.5) {
            entries.add(new PieEntry((float)bmi, "Your BMI"));
            entries.add(new PieEntry((float)(18.5 - bmi), "To Normal"));
            entries.add(new PieEntry(6.5f, "Normal Range"));
            entries.add(new PieEntry(5f, "Overweight"));
            entries.add(new PieEntry(10f, "Obese"));
        } else if (bmi < 25) {
            entries.add(new PieEntry(18.5f, "Underweight"));
            entries.add(new PieEntry((float)(bmi - 18.5), "Your BMI"));
            entries.add(new PieEntry((float)(25 - bmi), "To Overweight"));
            entries.add(new PieEntry(5f, "Overweight"));
            entries.add(new PieEntry(10f, "Obese"));
        } else if (bmi < 30) {
            entries.add(new PieEntry(18.5f, "Underweight"));
            entries.add(new PieEntry(6.5f, "Normal"));
            entries.add(new PieEntry((float)(bmi - 25), "Your BMI"));
            entries.add(new PieEntry((float)(30 - bmi), "To Obese"));
            entries.add(new PieEntry(10f, "Obese"));
        } else {
            entries.add(new PieEntry(18.5f, "Underweight"));
            entries.add(new PieEntry(6.5f, "Normal"));
            entries.add(new PieEntry(5f, "Overweight"));
            entries.add(new PieEntry((float)(bmi - 30), "Your BMI"));
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setColors(new int[] {
                Color.parseColor("#2196F3"),  // Your BMI - Blue
                Color.parseColor("#FFC107"),  // To Next Category - Yellow
                Color.parseColor("#4CAF50"),  // Normal Range - Green
                Color.parseColor("#FF9800"),  // Overweight - Orange
                Color.parseColor("#F44336")   // Obese - Red
        });

        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(11f);
        dataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.getDefault(), "%.1f", value);
            }
        });

        PieData pieData = new PieData(dataSet);
        chart.setData(pieData);

        // Styling
        chart.setUsePercentValues(false);
        chart.getDescription().setEnabled(false);
        chart.setDrawEntryLabels(false);
        chart.setDrawHoleEnabled(true);
        chart.setHoleColor(Color.TRANSPARENT);
        chart.setTransparentCircleRadius(25f);
        chart.setHoleRadius(25f);
        chart.setRotationAngle(0);
        chart.setRotationEnabled(false);

        // Legend
        Legend legend = chart.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        legend.setXEntrySpace(7f);
        legend.setYEntrySpace(5f);
        legend.setTextSize(12f);

        chart.animateY(1000);
        chart.invalidate();
    }

    private void setupLBMPieChart(PieChart chart, double lbm, boolean isMale, int age) {
        ArrayList<PieEntry> entries = new ArrayList<>();

        double idealLBM = calculateIdealLBM(isMale, age);
        double normal = Math.min(lbm, idealLBM);
        double deficit = Math.max(0, idealLBM - lbm);
        double excess = Math.max(0, lbm - idealLBM);

        entries.add(new PieEntry((float)normal, "Normal"));
        if (deficit > 0) {
            entries.add(new PieEntry((float)deficit, "Deficit"));
        }
        if (excess > 0) {
            entries.add(new PieEntry((float)excess, "Excess"));
        }

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setColors(new int[] {
                Color.parseColor("#4CAF50"),  // Normal - Green
                Color.parseColor("#F44336"),  // Deficit - Red
                Color.parseColor("#FFC107")   // Excess - Yellow
        });
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(11f);
        dataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return String.format(Locale.getDefault(), "%.1f kg", value);
            }
        });

        PieData pieData = new PieData(dataSet);
        chart.setData(pieData);

        // Same styling as BMI chart
        chart.setUsePercentValues(false);
        chart.getDescription().setEnabled(false);
        chart.setDrawEntryLabels(false);
        chart.setDrawHoleEnabled(true);
        chart.setHoleColor(Color.TRANSPARENT);
        chart.setTransparentCircleRadius(25f);
        chart.setHoleRadius(25f);
        chart.setRotationAngle(0);
        chart.setRotationEnabled(false);

        Legend legend = chart.getLegend();
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        legend.setDrawInside(false);
        legend.setXEntrySpace(7f);
        legend.setYEntrySpace(5f);
        legend.setTextSize(12f);

        chart.animateY(1000);
        chart.invalidate();
    }

    private void saveBmiRecord(String name, int age, double bmi, double lbm,
                               String category, double weightKg, double heightCm, boolean isMale) {
        if (currentUser == null) return;

        SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        isoFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        String timestamp = isoFormat.format(new Date());

        Map<String, Object> record = new HashMap<>();
        record.put("name", name);
        record.put("age", age);
        record.put("bmi", bmi);
        record.put("lbm", lbm);
        record.put("category", category);
        record.put("weightKg", weightKg);
        record.put("heightCm", heightCm);
        record.put("gender", isMale ? "Male" : "Female");
        record.put("timestamp", timestamp);

        String recordId = databaseReference.child(currentUser.getUid()).child("bmi_records").push().getKey();
        if (recordId != null) {
            databaseReference.child(currentUser.getUid()).child("bmi_records").child(recordId).setValue(record);
        }
    }
}