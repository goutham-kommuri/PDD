package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class UniversalHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    private List<HistoryItem> historyItems = new ArrayList<>();
    private String currentCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        currentCategory = getIntent().getStringExtra("CATEGORY_NAME");
        if (currentCategory == null) {
            finish();
            return;
        }

        initializeViews();
        loadHistory();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerViewHistory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new HistoryAdapter(historyItems);
        recyclerView.setAdapter(adapter);
    }

    private void loadHistory() {
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference dbRef;

        switch (currentCategory) {
            case "BMI":
                dbRef = FirebaseDatabase.getInstance().getReference()
                        .child("bmi_records").child(uid);
                break;
            case "CrCl":
                dbRef = FirebaseDatabase.getInstance().getReference()
                        .child("records").child(uid);
                break;
            case "Drug Dosage":
                dbRef = FirebaseDatabase.getInstance().getReference()
                        .child("drugdosage").child(uid);
                break;
            default: // Medication categories
                dbRef = FirebaseDatabase.getInstance().getReference()
                        .child("calculations").child(uid).child(currentCategory);
                break;
        }

        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                historyItems.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    HistoryItem item = createHistoryItem(ds);
                    if (item != null) {
                        historyItems.add(item);
                    }
                }
                Collections.sort(historyItems, (i1, i2) ->
                        Long.compare(i2.getTimestamp(), i1.getTimestamp()));
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(UniversalHistoryActivity.this,
                        "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private HistoryItem createHistoryItem(DataSnapshot ds) {
        switch (currentCategory) {
            case "BMI":
                return createBmiItem(ds);
            case "CrCl":
                return createCrclItem(ds);
            case "Drug Dosage":
                return createDrugDosageItem(ds);
            default:
                return createMedicationItem(ds);
        }
    }

    private HistoryItem createBmiItem(DataSnapshot ds) {
        HistoryItem item = new HistoryItem();
        item.setId(ds.getKey());
        item.setCategory(currentCategory);

        String name = ds.child("name").getValue(String.class);
        Double bmi = ds.child("bmi").getValue(Double.class);
        String category = ds.child("category").getValue(String.class);
        String suggestion = ds.child("suggestion").getValue(String.class);
        Long timestamp = parseTimestamp(ds.child("timestamp"));

        item.setTitle(name != null ? name : "BMI Calculation");
        item.setValue1(bmi != null ? String.format(Locale.getDefault(), "BMI: %.1f", bmi) : "");
        item.setValue2(category != null ? "Category: " + category : "");
        item.setResult(suggestion != null ? suggestion : "");
        item.setTimestamp(timestamp != null ? timestamp : System.currentTimeMillis());

        return item;
    }

    private HistoryItem createCrclItem(DataSnapshot ds) {
        HistoryItem item = new HistoryItem();
        item.setId(ds.getKey());
        item.setCategory(currentCategory);

        String patientName = ds.child("patientName").getValue(String.class);
        Double crCl = ds.child("crCl").getValue(Double.class);
        Double serumCreatinine = ds.child("serumCreatinine").getValue(Double.class);
        Long timestamp = parseTimestamp(ds.child("timestamp"));

        item.setTitle(patientName != null ? patientName : "CrCl Calculation");
        item.setValue1(crCl != null ? String.format(Locale.getDefault(), "CrCl: %.2f mL/min", crCl) : "");
        item.setValue2(serumCreatinine != null ?
                String.format(Locale.getDefault(), "SCr: %.2f mg/dL", serumCreatinine) : "");
        item.setResult("");
        item.setTimestamp(timestamp != null ? timestamp : System.currentTimeMillis());

        return item;
    }

    private HistoryItem createDrugDosageItem(DataSnapshot ds) {
        HistoryItem item = new HistoryItem();
        item.setId(ds.getKey());
        item.setCategory(currentCategory);

        String patientName = ds.child("patientName").getValue(String.class);
        String drugName = ds.child("drugName").getValue(String.class);
        String dosageResult = ds.child("dosageResult").getValue(String.class);
        Long timestamp = parseTimestamp(ds.child("timestamp"));

        item.setTitle(patientName != null ? patientName : "Drug Dosage");
        item.setValue1(drugName != null ? "Drug: " + drugName : "");
        item.setValue2("");
        item.setResult(dosageResult != null ? dosageResult : "");
        item.setTimestamp(timestamp != null ? timestamp : System.currentTimeMillis());

        return item;
    }

    private HistoryItem createMedicationItem(DataSnapshot ds) {
        HistoryItem item = new HistoryItem();
        item.setId(ds.getKey());
        item.setCategory(currentCategory);

        String drug = ds.child("drug").getValue(String.class);
        String result = ds.child("result").getValue(String.class);
        Double value = ds.child("value").getValue(Double.class);
        Boolean isWeightBased = ds.child("isWeightBased").getValue(Boolean.class);
        Integer age = ds.child("age").getValue(Integer.class);
        Integer ageMonths = ds.child("ageMonths").getValue(Integer.class);
        Long timestamp = parseTimestamp(ds.child("timestamp"));

        item.setTitle(drug != null ? drug : "Medication Calculation");
        item.setValue1(isWeightBased != null && isWeightBased && value != null ?
                String.format(Locale.getDefault(), "Weight: %.1f kg", value) : "");
        item.setValue2(age != null && age > 0 ?
                String.format(Locale.getDefault(), "Age: %d yrs", age) :
                ageMonths != null && ageMonths > 0 ?
                        String.format(Locale.getDefault(), "Age: %d months", ageMonths) : "");
        item.setResult(result != null ? result : "");
        item.setTimestamp(timestamp != null ? timestamp : System.currentTimeMillis());

        return item;
    }

    private Long parseTimestamp(DataSnapshot timestampSnapshot) {
        if (timestampSnapshot == null) {
            return null;
        }

        Object timestampObj = timestampSnapshot.getValue();
        if (timestampObj instanceof Long) {
            return (Long) timestampObj;
        } else if (timestampObj instanceof String) {
            try {
                // Parse ISO 8601 timestamp string
                return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault())
                        .parse((String) timestampObj).getTime();
            } catch (Exception e) {
                return null;
            }
        } else if (timestampObj instanceof Double) {
            return ((Double) timestampObj).longValue();
        }
        return null;
    }

    private class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

        private List<HistoryItem> historyItems;

        public HistoryAdapter(List<HistoryItem> historyItems) {
            this.historyItems = historyItems;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_history, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            HistoryItem item = historyItems.get(position);

            holder.tvDrugName.setText(item.getTitle());
            holder.tvDetails.setText(formatDetails(item));
            holder.tvTimestamp.setText(formatDate(item.getTimestamp()));
            holder.tvResultPreview.setText(item.getResult());

            holder.itemView.setOnClickListener(v -> showDetailsDialog(item));
        }

        private String formatDetails(HistoryItem item) {
            StringBuilder sb = new StringBuilder();
            if (!item.getValue1().isEmpty()) {
                sb.append(item.getValue1());
            }
            if (!item.getValue2().isEmpty()) {
                if (sb.length() > 0) sb.append(" | ");
                sb.append(item.getValue2());
            }
            return sb.toString();
        }

        private String formatDate(long timestamp) {
            return new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
                    .format(new Date(timestamp));
        }

        private void showDetailsDialog(HistoryItem item) {
            new AlertDialog.Builder(UniversalHistoryActivity.this)
                    .setTitle(item.getTitle() + " Details")
                    .setMessage(buildFullDetails(item))
                    .setPositiveButton("OK", null)
                    .show();
        }

        private String buildFullDetails(HistoryItem item) {
            StringBuilder sb = new StringBuilder();
            sb.append("Category: ").append(item.getCategory()).append("\n\n");
            sb.append(item.getTitle()).append("\n");

            if (!item.getValue1().isEmpty()) {
                sb.append(item.getValue1()).append("\n");
            }
            if (!item.getValue2().isEmpty()) {
                sb.append(item.getValue2()).append("\n");
            }

            if (!item.getResult().isEmpty()) {
                sb.append("\nResult:\n").append(item.getResult()).append("\n");
            }

            sb.append("\nDate: ").append(formatDate(item.getTimestamp()));

            return sb.toString();
        }

        @Override
        public int getItemCount() {
            return historyItems.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvDrugName, tvDetails, tvTimestamp, tvResultPreview;

            ViewHolder(View itemView) {
                super(itemView);
                tvDrugName = itemView.findViewById(R.id.tvDrugName);
                tvDetails = itemView.findViewById(R.id.tvDetails);
                tvTimestamp = itemView.findViewById(R.id.tvTimestamp);
                tvResultPreview = itemView.findViewById(R.id.tvResultPreview);
            }
        }
    }

    public static class HistoryItem {
        private String id;
        private String category;
        private String title;
        private String value1;
        private String value2;
        private String result;
        private long timestamp;

        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        public String getCategory() { return category; }
        public void setCategory(String category) { this.category = category; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getValue1() { return value1; }
        public void setValue1(String value1) { this.value1 = value1; }
        public String getValue2() { return value2; }
        public void setValue2(String value2) { this.value2 = value2; }
        public String getResult() { return result; }
        public void setResult(String result) { this.result = result; }
        public long getTimestamp() { return timestamp; }
        public void setTimestamp(long timestamp) { this.timestamp = timestamp; }
    }
}