package com.example.myapplication;

import android.os.Bundle;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class GIT extends AppCompatActivity {

    private Spinner spinnerDrug;
    private EditText etAge, etInput;
    private RadioGroup radioGroup;
    private RadioButton radioWeight, radioAge;
    private Button btnCalculate;
    private TextView tvResult;
    private final DecimalFormat df = new DecimalFormat("0.00");

    // Firebase variables
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gitdrugs);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        initializeViews();
        setupDrugSpinner();
        setupCalculateButton();
    }

    private void initializeViews() {
        spinnerDrug = findViewById(R.id.spinnerDrug);
        etAge = findViewById(R.id.etAge);
        etInput = findViewById(R.id.etInput);
        radioGroup = findViewById(R.id.radioGroup);
        radioWeight = findViewById(R.id.radioWeight);
        radioAge = findViewById(R.id.radioAge);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);
    }

    private void setupDrugSpinner() {
        String[] drugs = {"Select a drug", "Omeprazole", "Ranitidine", "Loperamide", "Metoclopramide"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, drugs);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDrug.setAdapter(adapter);
    }

    private void setupCalculateButton() {
        btnCalculate.setOnClickListener(v -> {
            try {
                calculateDosage();
            } catch (Exception e) {
                showToast("Calculation error: " + e.getMessage());
            }
        });
    }

    private void calculateDosage() {
        String selectedDrug = spinnerDrug.getSelectedItem().toString();
        String ageText = etAge.getText().toString().trim();
        String inputText = etInput.getText().toString().trim();

        if (selectedDrug.equals("Select a drug")) {
            tvResult.setText("Please select a medication.");
            return;
        }

        if (inputText.isEmpty()) {
            showToast("Please enter weight or age");
            return;
        }

        double inputValue = parseInputValue(inputText);
        if (inputValue <= 0) {
            showToast("Value must be positive");
            return;
        }

        int age = ageText.isEmpty() ? -1 : Integer.parseInt(ageText);
        boolean isWeightBased = radioWeight.isChecked();
        String result = generateDosingRecommendation(selectedDrug, inputValue, age, isWeightBased);
        tvResult.setText(result);

        // Save to Firebase
        saveCalculationToDatabase(selectedDrug, inputValue, age, isWeightBased, result);
    }

    private void saveCalculationToDatabase(String drug, double value, int age, boolean isWeightBased, String result) {
        if (mAuth.getCurrentUser() == null) {
            showToast("Not logged in - calculation not saved");
            return;
        }

        String uid = mAuth.getCurrentUser().getUid();
        DatabaseReference userCalculationsRef = mDatabase.child("calculations")
                .child(uid)
                .child("git");

        String calculationId = userCalculationsRef.push().getKey();

        Map<String, Object> calculationData = new HashMap<>();
        calculationData.put("drug", drug);
        calculationData.put("value", value);
        calculationData.put("age", age);
        calculationData.put("isWeightBased", isWeightBased);
        calculationData.put("result", result);
        calculationData.put("timestamp", System.currentTimeMillis());

        if (calculationId != null) {
            userCalculationsRef.child(calculationId).setValue(calculationData)
                    .addOnSuccessListener(aVoid -> showToast("Calculation saved to history"))
                    .addOnFailureListener(e -> showToast("Failed to save calculation"));
        }
    }

    private String generateDosingRecommendation(String drug, double value, int age, boolean isWeightBased) {
        StringBuilder sb = new StringBuilder();
        switch (drug) {
            case "Omeprazole":
                sb.append("Recommended dosage: ").append(df.format(isWeightBased ? value * 0.7 : age * 1.5)).append(" mg");
                sb.append("\nSuggestion: Take before meals for best effect.");
                break;
            case "Ranitidine":
                sb.append("Recommended dosage: ").append(df.format(isWeightBased ? value * 2 : age * 3)).append(" mg");
                sb.append("\nSuggestion: Can be taken with or without food.");
                break;
            case "Loperamide":
                sb.append("Recommended dosage: ").append(df.format(isWeightBased ? value * 0.3 : age * 1)).append(" mg");
                sb.append("\nSuggestion: Do not exceed recommended dose; consult a doctor if diarrhea persists.");
                break;
            case "Metoclopramide":
                sb.append("Recommended dosage: ").append(df.format(isWeightBased ? value * 0.5 : age * 2)).append(" mg");
                sb.append("\nSuggestion: Take 30 minutes before meals to reduce nausea.");
                break;
            default:
                sb.append("Consult a specialist for this medication.");
        }
        return sb.toString();
    }

    private double parseInputValue(String inputText) {
        try {
            return Double.parseDouble(inputText);
        } catch (NumberFormatException e) {
            showToast("Invalid number format");
            return 0;
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}