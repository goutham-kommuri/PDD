package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;

public class MedicationGuideActivity extends AppCompatActivity {
    private TabLayout medicationCategoryTabs;
    private RecyclerView medicationRecyclerView;
    private MedicationListAdapter medicationAdapter;
    private List<MedicationItem> allMedications = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_antibiotics);

        getWindow().setStatusBarColor(ContextCompat.getColor(this, android.R.color.white));

        medicationCategoryTabs = findViewById(R.id.tabLayout);
        medicationRecyclerView = findViewById(R.id.recyclerView);
        SearchView medicationSearchView = findViewById(R.id.searchView);

        customizeSearchView(medicationSearchView);
        ImageButton navigationBackButton = findViewById(R.id.backButton);
        navigationBackButton.setOnClickListener(v -> finish());

        initializeTabs();
        setupMedicationList();
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        populateMedicationData();
        filterMedicationsByCategory("Penicillins");

        medicationCategoryTabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterMedicationsByCategory(tab.getText().toString());
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        medicationSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                searchMedications(query);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                searchMedications(newText);
                return false;
            }
        });
    }

    private void customizeSearchView(SearchView searchView) {
        try {
            int searchTextId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_src_text", null, null);
            TextView searchText = searchView.findViewById(searchTextId);
            searchText.setTextColor(Color.BLACK);
            searchText.setHintTextColor(Color.GRAY);

            ImageView searchIcon = searchView.findViewById(androidx.appcompat.R.id.search_button);
            if (searchIcon != null) searchIcon.setColorFilter(Color.BLACK);

            ImageView closeIcon = searchView.findViewById(androidx.appcompat.R.id.search_close_btn);
            if (closeIcon != null) closeIcon.setColorFilter(Color.BLACK);

            int voiceIconId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_voice_btn", null, null);
            ImageView voiceIcon = searchView.findViewById(voiceIconId);
            if (voiceIcon != null) voiceIcon.setColorFilter(Color.BLACK);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void populateMedicationData() {
        allMedications.clear();

        // Enhanced Penicillins
        allMedications.add(new MedicationItem("Amoxicillin", "Penicillin", "Oral/IV",
                "1-2 hours", "6-8 hours", "250-500 mg every 8 hours (adults)",
                "• First-line for otitis media, sinusitis, strep throat\n" +
                        "• Spectrum: Gram-positive cocci, some Gram-negative\n" +
                        "• Side effects: Rash, diarrhea, allergic reactions\n" +
                        "• Resistance: Susceptible to beta-lactamases", "Penicillins"));

        allMedications.add(new MedicationItem("Amoxicillin-Clavulanate", "Penicillin/BLI", "Oral/IV",
                "1-2 hours", "6-8 hours", "500-875 mg every 8-12 hours (based on amoxicillin)",
                "• Enhanced spectrum with beta-lactamase inhibitor\n" +
                        "• Covers anaerobes, H. influenzae, Moraxella\n" +
                        "• Common for bite wounds, sinusitis, COPD exacerbations\n" +
                        "• Diarrhea more common than with plain amoxicillin", "Penicillins"));

        allMedications.add(new MedicationItem("Piperacillin-Tazobactam", "Penicillin/BLI", "IV",
                "Immediate", "4-6 hours", "3.375-4.5 g every 6-8 hours",
                "• Broadest spectrum penicillin\n" +
                        "• Covers Pseudomonas, Enterobacteriaceae, anaerobes\n" +
                        "• Hospital-acquired infections, intra-abdominal infections\n" +
                        "• Requires renal dose adjustment", "Penicillins"));

        // Enhanced Cephalosporins
        allMedications.add(new MedicationItem("Cefazolin", "1st Gen Cephalosporin", "IV/IM",
                "Immediate", "8 hours", "1-2 g every 8 hours",
                "• Surgical prophylaxis (especially for skin flora)\n" +
                        "• MSSA coverage (not MRSA)\n" +
                        "• No CNS penetration\n" +
                        "• Renal dosing required", "Cephalosporins"));

        allMedications.add(new MedicationItem("Ceftriaxone", "3rd Gen Cephalosporin", "IV/IM",
                "Immediate", "24 hours", "1-2 g every 24 hours",
                "• Long half-life allows once-daily dosing\n" +
                        "• Excellent CSF penetration (meningitis treatment)\n" +
                        "• Covers N. gonorrhoeae, S. pneumoniae, H. influenzae\n" +
                        "• Can cause biliary pseudolithiasis", "Cephalosporins"));

        allMedications.add(new MedicationItem("Ceftazidime-Avibactam", "3rd Gen + BLI", "IV",
                "Immediate", "8 hours", "2.5 g every 8 hours",
                "• Targets resistant Gram-negatives including ESBLs\n" +
                        "• Pseudomonas coverage retained\n" +
                        "• Used for complicated UTIs, intra-abdominal infections\n" +
                        "• Very expensive, reserve for resistant cases", "Cephalosporins"));

        // Enhanced Macrolides
        allMedications.add(new MedicationItem("Azithromycin", "Macrolide", "Oral/IV",
                "2-4 hours", "68 hours", "500 mg daily for 3 days (typical course)",
                "• Long tissue half-life allows short courses\n" +
                        "• Atypical coverage (Legionella, Mycoplasma, Chlamydia)\n" +
                        "• QT prolongation risk, especially with other QT drugs\n" +
                        "• Minimal CYP450 interactions compared to other macrolides", "Macrolides"));

        allMedications.add(new MedicationItem("Clarithromycin", "Macrolide", "Oral",
                "2-4 hours", "12 hours", "250-500 mg every 12 hours",
                "• Better Gram-positive coverage than azithromycin\n" +
                        "• Part of H. pylori and MAC regimens\n" +
                        "• Strong CYP3A4 inhibitor - many drug interactions\n" +
                        "• Metallic taste side effect common", "Macrolides"));

        // Enhanced Fluoroquinolones
        allMedications.add(new MedicationItem("Ciprofloxacin", "Fluoroquinolone", "Oral/IV",
                "1-2 hours", "12 hours", "250-750 mg every 12 hours",
                "• Best Gram-negative coverage in class\n" +
                        "• Only fluoroquinolone with Pseudomonas coverage\n" +
                        "• Black box warnings for tendon rupture, CNS effects\n" +
                        "• Avoid in myasthenia gravis", "Fluoroquinolones"));

        allMedications.add(new MedicationItem("Moxifloxacin", "Fluoroquinolone", "Oral/IV",
                "1-2 hours", "24 hours", "400 mg daily",
                "• Broadest spectrum in class (includes anaerobes)\n" +
                        "• Good for CAP, intra-abdominal infections\n" +
                        "• Higher QT risk than other FQs\n" +
                        "• No dose adjustment in renal impairment", "Fluoroquinolones"));

        // Remove "Others" category and add more specific ones
        allMedications.add(new MedicationItem("Vancomycin", "Glycopeptide", "IV",
                "Immediate", "8-12 hours", "15-20 mg/kg every 8-12 hours",
                "• MRSA, coagulase-negative staph coverage\n" +
                        "• Requires trough monitoring (target 10-20 mcg/mL)\n" +
                        "• Red man syndrome (not true allergy)\n" +
                        "• Nephrotoxicity risk with other nephrotoxic drugs", "Glycopeptides"));

        allMedications.add(new MedicationItem("Daptomycin", "Lipopeptide", "IV",
                "Immediate", "24 hours", "4-6 mg/kg daily",
                "• MRSA, VRE coverage\n" +
                        "• Bactericidal concentration-dependent killing\n" +
                        "• CPK monitoring required (myopathy risk)\n" +
                        "• Inactivated by pulmonary surfactant - not for pneumonia", "Lipopeptides"));

        // Add Carbapenems as a new category
        allMedications.add(new MedicationItem("Meropenem", "Carbapenem", "IV",
                "Immediate", "8 hours", "1 g every 8 hours",
                "• Broadest spectrum beta-lactam\n" +
                        "• ESBL-producing organisms, MDR Gram-negatives\n" +
                        "• Seizure risk (less than imipenem)\n" +
                        "• Renal dose adjustment required", "Carbapenems"));
    }
    private void filterMedicationsByCategory(String category) {
        List<MedicationItem> filtered = new ArrayList<>();
        for (MedicationItem item : allMedications) {
            if (item.getCategory().equals(category)) {
                filtered.add(item);
            }
        }
        medicationAdapter.updateMedicationList(filtered);
    }

    private void searchMedications(String query) {
        String currentTab = medicationCategoryTabs.getTabAt(medicationCategoryTabs.getSelectedTabPosition()).getText().toString();
        List<MedicationItem> filtered = new ArrayList<>();

        for (MedicationItem item : allMedications) {
            if (item.getCategory().equals(currentTab) &&
                    item.getName().toLowerCase().contains(query.toLowerCase())) {
                filtered.add(item);
            }
        }
        medicationAdapter.updateMedicationList(filtered);
    }

    private void initializeTabs() {
        medicationCategoryTabs.addTab(medicationCategoryTabs.newTab().setText("Penicillins"));
        medicationCategoryTabs.addTab(medicationCategoryTabs.newTab().setText("Cephalosporins"));
        medicationCategoryTabs.addTab(medicationCategoryTabs.newTab().setText("Macrolides"));
        medicationCategoryTabs.addTab(medicationCategoryTabs.newTab().setText("Fluoroquinolones"));

    }

    private void setupMedicationList() {
        medicationRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        medicationAdapter = new MedicationListAdapter(new ArrayList<>());
        medicationRecyclerView.setAdapter(medicationAdapter);
    }
}