package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DrugAdapter extends RecyclerView.Adapter<DrugAdapter.ViewHolder> {
    private List<Drug> drugList;

    public DrugAdapter(List<Drug> drugList) {
        this.drugList = drugList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_drug_table, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Drug drug = drugList.get(position);

        holder.drugName.setText(drug.getName());
        holder.drugType.setText(drug.getType());
        holder.drugRoute.setText(drug.getRoute());
        holder.drugOnset.setText("Onset Time: " + drug.getOnset());
        holder.drugDuration.setText("Duration: " + drug.getDuration());
        holder.drugDosage.setText("Dosage: " + drug.getDosage());
        holder.drugConsiderations.setText("Special Considerations: " + drug.getConsiderations());
    }

    @Override
    public int getItemCount() {
        return drugList.size();
    }

    public void updateList(List<Drug> newList) {
        drugList = newList;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView drugName, drugType, drugRoute, drugOnset,
                drugDuration, drugDosage, drugConsiderations;

        ViewHolder(View itemView) {
            super(itemView);
            drugName = itemView.findViewById(R.id.drugName);
            drugType = itemView.findViewById(R.id.drugType);
            drugRoute = itemView.findViewById(R.id.drugRoute);
            drugOnset = itemView.findViewById(R.id.drugOnset);
            drugDuration = itemView.findViewById(R.id.drugDuration);
            drugDosage = itemView.findViewById(R.id.drugDosage);
            drugConsiderations = itemView.findViewById(R.id.drugConsiderations);
        }
    }
}