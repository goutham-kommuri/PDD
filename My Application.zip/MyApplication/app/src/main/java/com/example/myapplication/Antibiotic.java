package com.example.myapplication;

import android.os.Bundle;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

public class Antibiotic extends AppCompatActivity {

    private Spinner spinnerDrug;
    private EditText etAge, etInput;
    private RadioGroup radioGroup;
    private RadioButton radioWeight, radioAge;
    private Button btnCalculate;
    private TextView tvResult;
    private final DecimalFormat df = new DecimalFormat("0.00");

    // Firebase variables
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.antibiotics);
        if (getSupportActionBar() != null) getSupportActionBar().hide();

        // Initialize Firebase
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        initializeViews();
        setupDrugSpinner();
        setupCalculateButton();
    }

    private void initializeViews() {
        spinnerDrug = findViewById(R.id.spinnerDrug);
        etAge = findViewById(R.id.etAge);
        etInput = findViewById(R.id.etInput);
        radioGroup = findViewById(R.id.radioGroup);
        radioWeight = findViewById(R.id.radioWeight);
        radioAge = findViewById(R.id.radioAge);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);
    }

    private void setupDrugSpinner() {
        String[] drugs = {
                "Select a drug", "Amoxicillin", "Azithromycin", "Ceftriaxone", "Ciprofloxacin"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, drugs);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDrug.setAdapter(adapter);
    }

    private void setupCalculateButton() {
        btnCalculate.setOnClickListener(v -> {
            try {
                calculateDosage();
            } catch (Exception e) {
                showToast("Calculation error: " + e.getMessage());
            }
        });
    }

    private void calculateDosage() {
        String selectedDrug = spinnerDrug.getSelectedItem().toString();
        String ageText = etAge.getText().toString().trim();
        String inputText = etInput.getText().toString().trim();

        if (selectedDrug.equals("Select a drug")) {
            tvResult.setText("Please select a medication.");
            return;
        }

        if (inputText.isEmpty()) {
            showToast("Please enter weight/age");
            return;
        }

        double inputValue = parseInputValue(inputText);
        if (inputValue <= 0) {
            showToast("Value must be positive");
            return;
        }

        int age = ageText.isEmpty() ? -1 : Integer.parseInt(ageText);
        boolean isWeightBased = radioWeight.isChecked();
        String result = generateDosingRecommendation(selectedDrug, inputValue, age, isWeightBased);
        tvResult.setText(result);

        // Save to database
        saveCalculationToDatabase(selectedDrug, inputValue, age, isWeightBased, result);
    }

    private String generateDosingRecommendation(String drug, double value, int age, boolean isWeightBased) {
        StringBuilder sb = new StringBuilder();
        switch (drug) {
            case "Amoxicillin":
                sb.append("Recommended dosage: ").append(isWeightBased ? value * 20 : age * 5).append(" mg");
                sb.append("\nSuggestion: Take after food to avoid stomach upset.");
                break;
            case "Azithromycin":
                sb.append("Recommended dosage: ").append(isWeightBased ? value * 10 : age * 3).append(" mg");
                sb.append("\nSuggestion: Best taken on an empty stomach for better absorption.");
                break;
            case "Ceftriaxone":
                sb.append("Recommended dosage: ").append(isWeightBased ? value * 50 : age * 15).append(" mg");
                sb.append("\nSuggestion: Usually administered via injection; consult a doctor.");
                break;
            case "Ciprofloxacin":
                sb.append("Recommended dosage: ").append(isWeightBased ? value * 15 : age * 4).append(" mg");
                sb.append("\nSuggestion: Avoid dairy and caffeine while taking this medication.");
                break;
            default:
                sb.append("Consult specialist for this medication");
        }
        return sb.toString();
    }

    private void saveCalculationToDatabase(String drug, double value, int age, boolean isWeightBased, String result) {
        String uid = mAuth.getCurrentUser().getUid();
        DatabaseReference userCalculationsRef = mDatabase.child("calculations").child(uid).child("antibiotic");

        String calculationId = userCalculationsRef.push().getKey();

        Map<String, Object> calculationData = new HashMap<>();
        calculationData.put("drug", drug);
        calculationData.put("value", value);
        calculationData.put("age", age);
        calculationData.put("isWeightBased", isWeightBased);
        calculationData.put("result", result);
        calculationData.put("timestamp", ServerValue.TIMESTAMP);

        userCalculationsRef.child(calculationId).setValue(calculationData)
                .addOnSuccessListener(aVoid -> showToast("Calculation saved"))
                .addOnFailureListener(e -> showToast("Failed to save calculation"));
    }

    private double parseInputValue(String inputText) {
        try {
            return Double.parseDouble(inputText);
        } catch (NumberFormatException e) {
            showToast("Invalid number format");
            return 0;
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}