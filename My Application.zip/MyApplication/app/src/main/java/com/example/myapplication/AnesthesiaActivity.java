package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;

public class AnesthesiaActivity extends AppCompatActivity {
    private TabLayout tabLayout;
    private RecyclerView recyclerView;
    private DrugAdapter adapter;
    private List<Drug> allDrugs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anesthesia);

        // Set status bar color
        getWindow().setStatusBarColor(ContextCompat.getColor(this, android.R.color.white));

        tabLayout = findViewById(R.id.tabLayout);
        recyclerView = findViewById(R.id.recyclerView);
        SearchView searchView = findViewById(R.id.searchView);

        // Style the SearchView
        styleSearchView(searchView);
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(v -> finish());
        // Setup tabs
        tabLayout.addTab(tabLayout.newTab().setText("General"));
        tabLayout.addTab(tabLayout.newTab().setText("Local"));
        tabLayout.addTab(tabLayout.newTab().setText("Neuromuscular"));

        // Setup RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DrugAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);
        if (getSupportActionBar() != null) getSupportActionBar().hide();
        // Load all drugs
        loadAllDrugs();

        // Default to General tab
        filterDrugsByCategory("General");

        // Tab selection listener
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                filterDrugsByCategory(tab.getText().toString());
            }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });

        // Search functionality
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterDrugs(query);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                filterDrugs(newText);
                return false;
            }
        });
    }

    // Add this in your onCreate() after initializing the SearchView
    private void styleSearchView(SearchView searchView) {
        try {
            // Set text color
            int searchTextId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_src_text", null, null);
            TextView searchText = searchView.findViewById(searchTextId);
            searchText.setTextColor(Color.BLACK);
            searchText.setHintTextColor(Color.GRAY);

            // Set search icon color
            ImageView searchIcon = searchView.findViewById(androidx.appcompat.R.id.search_button);
            if (searchIcon != null) {
                searchIcon.setColorFilter(Color.BLACK);
            }

            // Set close icon color
            ImageView closeIcon = searchView.findViewById(androidx.appcompat.R.id.search_close_btn);
            if (closeIcon != null) {
                closeIcon.setColorFilter(Color.BLACK);
            }

            // Set voice icon color if exists
            int voiceIconId = searchView.getContext().getResources()
                    .getIdentifier("android:id/search_voice_btn", null, null);
            ImageView voiceIcon = searchView.findViewById(voiceIconId);
            if (voiceIcon != null) {
                voiceIcon.setColorFilter(Color.BLACK);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadAllDrugs() {
        allDrugs.clear();

        // General Anesthetics
        allDrugs.add(new Drug("Propofol", "General Anesthetic", "Intravenous",
                "30-40 seconds", "3-10 minutes", "1.5-2.5 mg/kg",
                "Monitor blood pressure and respiratory function", "General"));

        allDrugs.add(new Drug("Sevoflurane", "General Anesthetic", "Inhalation",
                "< 2 minutes", "5-10 minutes", "0.5-3% concentration",
                "Monitor end-tidal concentration", "General"));

        allDrugs.add(new Drug("Isoflurane", "General Anesthetic", "Inhalation",
                "2-5 minutes", "10-20 minutes", "1-2.5% concentration",
                "May cause respiratory depression", "General"));

        allDrugs.add(new Drug("Ketamine", "General Anesthetic", "IV/IM",
                "30-60 seconds", "5-15 minutes", "1-2 mg/kg IV, 4-6 mg/kg IM",
                "Increases blood pressure and heart rate", "General"));

        // Local Anesthetics
        allDrugs.add(new Drug("Lidocaine", "Local Anesthetic", "Injection/Topical",
                "2-5 minutes", "30-60 minutes", "1-5 mg/kg",
                "Check for allergies, avoid intravascular injection", "Local"));

        allDrugs.add(new Drug("Bupivacaine", "Local Anesthetic", "Injection",
                "5-10 minutes", "2-4 hours", "2-3 mg/kg",
                "Long-acting, monitor for toxicity", "Local"));

        allDrugs.add(new Drug("Ropivacaine", "Local Anesthetic", "Injection",
                "10-20 minutes", "3-6 hours", "2-3 mg/kg",
                "Less cardiotoxic than bupivacaine", "Local"));

        allDrugs.add(new Drug("Mepivacaine", "Local Anesthetic", "Injection",
                "3-5 minutes", "45-90 minutes", "4-5 mg/kg",
                "Good for dental procedures", "Local"));

        // Neuromuscular Blockers
        allDrugs.add(new Drug("Rocuronium", "Neuromuscular Blocker", "Intravenous",
                "1-2 minutes", "20-35 minutes", "0.6-1.2 mg/kg",
                "Monitor neuromuscular function", "Neuromuscular"));

        allDrugs.add(new Drug("Succinylcholine", "Neuromuscular Blocker", "Intravenous",
                "30-60 seconds", "5-10 minutes", "1-2 mg/kg",
                "Risk of hyperkalemia, malignant hyperthermia", "Neuromuscular"));

        allDrugs.add(new Drug("Vecuronium", "Neuromuscular Blocker", "Intravenous",
                "2-3 minutes", "30-40 minutes", "0.08-0.1 mg/kg",
                "Intermediate duration, no histamine release", "Neuromuscular"));

        allDrugs.add(new Drug("Cisatracurium", "Neuromuscular Blocker", "Intravenous",
                "2-3 minutes", "40-60 minutes", "0.1-0.2 mg/kg",
                "Hofmann elimination, good for renal failure", "Neuromuscular"));
    }

    private void filterDrugsByCategory(String category) {
        List<Drug> filtered = new ArrayList<>();
        for (Drug drug : allDrugs) {
            if (drug.getCategory().equals(category)) {
                filtered.add(drug);
            }
        }
        adapter.updateList(filtered);
    }

    private void filterDrugs(String query) {
        String currentTab = tabLayout.getTabAt(tabLayout.getSelectedTabPosition()).getText().toString();
        List<Drug> filtered = new ArrayList<>();

        for (Drug drug : allDrugs) {
            if (drug.getCategory().equals(currentTab) &&
                    drug.getName().toLowerCase().contains(query.toLowerCase())) {
                filtered.add(drug);
            }
        }
        adapter.updateList(filtered);
    }
}