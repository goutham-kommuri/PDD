// AnticoagulantAdapter.java
package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AnticoagulantAdapter extends RecyclerView.Adapter<AnticoagulantAdapter.ViewHolder> {
    private List<Anticoagulant> anticoagulantList;

    public AnticoagulantAdapter(List<Anticoagulant> anticoagulantList) {
        this.anticoagulantList = anticoagulantList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_anticoagulant_table, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Anticoagulant anticoagulant = anticoagulantList.get(position);

        holder.anticoagulantName.setText(anticoagulant.getName());
        holder.anticoagulantClass.setText(anticoagulant.getDrugClass());
        holder.anticoagulantRoute.setText(anticoagulant.getRoute());
        holder.anticoagulantOnset.setText("Onset: " + anticoagulant.getOnset());
        holder.anticoagulantHalfLife.setText("Half-life: " + anticoagulant.getHalfLife());
        holder.anticoagulantReversal.setText("Reversal: " + anticoagulant.getReversalAgent());
        holder.anticoagulantMonitoring.setText("Monitoring: " + anticoagulant.getMonitoring());
        holder.anticoagulantConsiderations.setText("Considerations: " + anticoagulant.getConsiderations());
    }

    @Override
    public int getItemCount() {
        return anticoagulantList.size();
    }

    public void updateList(List<Anticoagulant> newList) {
        anticoagulantList = newList;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView anticoagulantName, anticoagulantClass, anticoagulantRoute, anticoagulantOnset,
                anticoagulantHalfLife, anticoagulantReversal, anticoagulantMonitoring, anticoagulantConsiderations;

        ViewHolder(View itemView) {
            super(itemView);
            anticoagulantName = itemView.findViewById(R.id.anticoagulantName);
            anticoagulantClass = itemView.findViewById(R.id.anticoagulantClass);
            anticoagulantRoute = itemView.findViewById(R.id.anticoagulantRoute);
            anticoagulantOnset = itemView.findViewById(R.id.anticoagulantOnset);
            anticoagulantHalfLife = itemView.findViewById(R.id.anticoagulantHalfLife);
            anticoagulantReversal = itemView.findViewById(R.id.anticoagulantReversal);
            anticoagulantMonitoring = itemView.findViewById(R.id.anticoagulantMonitoring);
            anticoagulantConsiderations = itemView.findViewById(R.id.anticoagulantConsiderations);
        }
    }
}